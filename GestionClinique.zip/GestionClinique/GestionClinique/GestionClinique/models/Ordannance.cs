﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionClinique.models
{
    public class Ordannance
    {
        private int id;
        private string nom;
        private List<Medicaments> medicaments;

        public List<Medicaments> Medicaments { get => medicaments; set => medicaments = value; }
    }
}
