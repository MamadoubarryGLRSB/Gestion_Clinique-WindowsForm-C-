﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionClinique.models
{
    public class Medicaments
    {
        private int id;
        
        private string type;
        private Ordannance ordannance;

        public int Id { get => id; set => id = value; }
        public string Type { get => type; set => type = value; }
    }
}
