﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionClinique.models
{
    public class Consultation
    {
        
        private string date;
        private string time;
        private string temperature;
        private string tension;
        private string poids;
        private Patient patient;
        private int id;
        private string nomMedecin;
        private string groupeSanguin;
        private string dateNaissance;
        private string telephone;
        private string adresse;
        private Medecin medecin;
        private string constantes;



        public int Id { get => id; set => id = value; }

        public string Date { get => date; set => date = value; }

        public string Time { get => time; set => time = value; }

        public Patient Patient { get => patient; set => patient = value; }




        public string Tension { get => tension; set => tension = value; }
        public string Poids { get => poids; set => poids = value; }
        public string Temperature { get => temperature; set => temperature = value; }
        public string NomMedecin { get => nomMedecin; set => nomMedecin = value; }
        public string GroupeSanguin { get => groupeSanguin; set => groupeSanguin = value; }
        public string DateNaissance { get => dateNaissance; set => dateNaissance = value; }
        public string Telephone { get => telephone; set => telephone = value; }
        public string Adresse { get => adresse; set => adresse = value; }
        public Medecin Medecin { get => medecin; set => medecin = value; }
        public string Constantes { get => constantes; set => constantes = value; }
    }
}
