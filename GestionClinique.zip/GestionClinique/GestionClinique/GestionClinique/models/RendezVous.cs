﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionClinique.models
{

    public class RendezVous
    {
        private int id;
        private string type;
        private string date;
        private string heure;
        private string etat;
        private Patient patient;
        private User medecin;
        public RendezVous()
        {
            Etat = "Confirmé";
        }

        public int Id { get => id; set => id = value; }
        public string Date { get => date; set => date = value; }
        public string Heure { get => heure; set => heure = value; }
        public string Type { get => type; set => type = value; }

        public string Etat { get => etat; set => etat = value; }
        public Patient Patient { get => patient; set => patient = value; }
        public User Medecin { get => medecin; set => medecin = value; }






        //public Medecin Medecin { get => medecin; set => medecin = value; }
    }
}
