﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionClinique.models
{
    public class Prestation
    {
        private int id;
        private string date;
        private string heure;
        private string typePrestation;
        private Patient patient;
        private string constantes;

        public int Id { get => id; set => id = value; }
        public string Date { get => date; set => date = value; }
        public string Heure { get => heure; set => heure = value; }
        public string TypePrestation { get => typePrestation; set => typePrestation = value; }
        public Patient Patient { get => patient; set => patient = value; }
        public string Constantes { get => constantes; set => constantes = value; }
    }
}
