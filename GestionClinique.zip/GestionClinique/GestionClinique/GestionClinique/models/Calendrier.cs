﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionClinique.models
{
    public class Calendrier
    {
        private string heure;
        private string jour;
        private Medecin medecin;

        public string Heure { get => heure; set => heure = value; }
        public string Jour { get => jour; set => jour = value; }
        public Medecin Medecin { get => medecin; set => medecin = value; }
    }
}
