﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionClinique.models
{
    public class Patient
    {
        private int id;
        private string nom;
        private string prenom;
        private string code;
        private static int nbr;
        private string antecedent;
        private string sexe;
        private string date_Naissance;
        private string adresse;
        private string telephone;


        public Patient()
        {
            nbr++;
     
            if(nbr>=100 ) {
                Code = "PAT"+nbr.ToString();            
            }
            else if(nbr < 100 && nbr >= 10){
                Code = "PAT0" + nbr.ToString();
            }
            else
            {
                Code = "PAT00" + nbr.ToString();
            }
        }

        public int Id { get => id; set => id = value; }
        public string Nom { get => nom; set => nom = value; }
        public string Prenom { get => prenom; set => prenom = value; }
        public string Code { get => code; set => code = value; }
        public string Antecedent { get => antecedent; set => antecedent = value; }
        public string Sexe { get => sexe; set => sexe = value; }
        public string Date_Naissance { get => date_Naissance; set => date_Naissance = value; }
        public string Adresse { get => adresse; set => adresse = value; }
        public string Telephone { get => telephone; set => telephone = value; }

        public override string ToString()
        {
            return nom +" "+ prenom;
        }
    }
}
