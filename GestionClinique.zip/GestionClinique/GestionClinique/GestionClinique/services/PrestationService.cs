﻿using GestionClinique.dto;
using GestionClinique.models;
using GestionClinique.repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionClinique.services
{
    public class PrestationService : IPrestationService
    {
        //Couplage faible
        private IPrestationRepository prestationRepository;

        public PrestationService(IPrestationRepository prestationRepository)
        {
            this.prestationRepository = prestationRepository;
        }

        public void ajouterPrestation(Prestation prestation)
        {
            prestationRepository.save(prestation);
        }

        public Prestation finfById(int id)
        {
            return prestationRepository.findById(id);
        }

        public List<PrestationDto> listerPrestationBydate(string date)
        {
            return prestationRepository.findByLibelle(date);
        }

        public List<PrestationDto> listerPrestationPatient(Patient patient)
        {
            return prestationRepository.findByLibellePatient(patient);
        }

        public List<PrestationDto> listerRdVPrestation()
        {
            return prestationRepository.findAll();
        }
    }
}
