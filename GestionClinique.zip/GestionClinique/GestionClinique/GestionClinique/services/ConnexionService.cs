﻿using GestionClinique.models;
using GestionClinique.repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionClinique.services
{
    public class ConnexionService : IConnexionService
    {
        private IUserRepository userRepository;

        public ConnexionService(IUserRepository userRepository)
        {
            this.userRepository = userRepository;
        }

        public User finfById(int id)
        {
            return userRepository.findById(id);
        }

        public List<User> listerMedecin()
        {
            return userRepository.findAll();
        }

        public User seConnecter(string login, string password)
        {
            User user = userRepository.FindByLogin(login);
            return (user == null || user.Password != password) ? null : user;
        }

        Rp IConnexionService.finfByIdRp(int id)
        {
            return userRepository.findByIdRp(id);
        }
    }
}
