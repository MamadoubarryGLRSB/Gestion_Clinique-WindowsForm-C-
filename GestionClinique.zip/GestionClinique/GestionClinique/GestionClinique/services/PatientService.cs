﻿using GestionClinique.dto;
using GestionClinique.models;
using GestionClinique.repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionClinique.services
{
    public class PatientService : IPatientService
    {
        //Couplage faible
        private IPatientRepository patientRepository;

        public PatientService(IPatientRepository patientRepository)
        {
            this.patientRepository = patientRepository;
        }

        public void ajouterPatient(Patient patient)
        {
            patientRepository.save(patient);
        }

        public Patient finfById(int id)
        {
            return patientRepository.findById(id);
        }

        public List<PatientDto> listerPatient()
        {
            return patientRepository.findAll();
        }

        public List<Patient> listerPatientP()
        {
            return patientRepository.findAllP();
        }

        public void modifierPatient(Patient patient)
        {
            patientRepository.edit(patient);
        }

        public void supprimerPatient(int id)
        {
           patientRepository.delete(id);
        }
    }
}
