﻿using GestionClinique.dto;
using GestionClinique.models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionClinique.services
{
    public interface IPrestationService
    {
        List<PrestationDto> listerRdVPrestation();
        List<PrestationDto> listerPrestationBydate(string date);
        List<PrestationDto> listerPrestationPatient(Patient patient);
        void ajouterPrestation(Prestation prestation);
        Prestation finfById(int id);

    }
}
