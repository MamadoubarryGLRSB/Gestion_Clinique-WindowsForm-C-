﻿using GestionClinique.models;
using GestionClinique.repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionClinique.services
{
    public class MedecinService : IMedecinService
    {
        private IMedecinRepository medecinRepository;

        public MedecinService(IMedecinRepository medecinRepository)
        {
            this.medecinRepository = medecinRepository;
        }

        public Medecin finfById(int id)
        {
            return medecinRepository.findById(id);
        }

        public List<Medecin> listerMedecin()
        {
            return medecinRepository.findAll();
        }
    }
}
