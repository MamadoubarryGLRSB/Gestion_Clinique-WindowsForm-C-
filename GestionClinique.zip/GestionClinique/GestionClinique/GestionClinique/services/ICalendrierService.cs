﻿using GestionClinique.models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionClinique.services
{
    public interface ICalendrierService
    {
        void ajouterCalendrier(Calendrier calendrier);
    }
}
