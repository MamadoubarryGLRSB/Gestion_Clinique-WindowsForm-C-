﻿using GestionClinique.dto;
using GestionClinique.models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionClinique.services
{
    public interface IMedecinService
    {
        List<Medecin> listerMedecin();
        Medecin finfById(int id);
    }
}
