﻿using GestionClinique.dto;
using GestionClinique.models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionClinique.services
{
    public interface IMedicamentService
    {
        List<Medicaments> listerMedicaments();
        void ajouterPatient(Medicaments medicaments);
    }
}
