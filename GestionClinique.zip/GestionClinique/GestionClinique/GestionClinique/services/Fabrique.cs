﻿using GestionClinique.models;
using GestionClinique.repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionClinique.services
{

    public class Fabrique
    {
        private static IRendezVousService rendezVousService;
        private static IConnexionService connexionService;
        private static IConsultationService consultationService;
        private static IPrestationService prestationService;
        private static IPatientService patientService;
        private static IMedicamentService medicamentService;
        private static IMedecinService medecinService;
        private static ICalendrierService calendrierService;
        private static string connectionString = @"Data Source=MBARRY\;Initial Catalog=Gestion_Clinique;Integrated Security=True";
        
        private static IUserRepository userRepository = new UserRepository(connectionString);
        private static IPatientRepository patientRepository = new PatientRepository(connectionString);

        private static IRendezVousRepository rendezVousRepository = new RendezVousRepository(connectionString,patientRepository,userRepository);

        
        private static IConsultationRepository consultationRepository = new ConsultationRepository(connectionString,patientRepository);
        private static IPrestationRepository prestationRepository = new PrestationRepository(connectionString, patientRepository);
        private static IMedicamentRepository medicamentRepository=new MedicamentRepository(connectionString);
        private static IMedecinRepository medecinRepository = new MedecinRepository(connectionString);
        private static ICalendrierRepository calendrierRepository=new CalendrierRepository(connectionString);
        public static ICalendrierService GetCalendrierService()
        {
            return calendrierService==null ? new CalendrierService(calendrierRepository):calendrierService;
        }
        public static IRendezVousService GetRendezVousService()
        {
            //Design Pattern Singleton : Garantir l'Unicité d'une instance
            return rendezVousService == null ? new RendezVousService(rendezVousRepository) : rendezVousService;


        }
        public static IMedecinService GetMedecinService()
        {
            return medecinService==null ? new MedecinService(medecinRepository): medecinService;
        }
        public static IMedicamentService GetMedicamentService()
        {
            return medicamentService==null ? new MedicamentService(medicamentRepository): medicamentService;
        }
        public static IConnexionService GetConnexionService()
        {
            //Design Pattern Singleton:Garantir l'unicité d'une instance

            return connexionService == null ? new ConnexionService(userRepository) : connexionService;

        }
        public static IConsultationService GetConsultationService()
        {
            return consultationService== null ? new ConsultationService(consultationRepository) : consultationService;
        }
        public static IPrestationService GetPrestationService()
        {
            return prestationService == null ? new PrestationService(prestationRepository) : prestationService;
        }
        public static IPatientService GetPatientService()
        {
            return patientService == null ? new PatientService(patientRepository) : patientService;
        }


    }
}
