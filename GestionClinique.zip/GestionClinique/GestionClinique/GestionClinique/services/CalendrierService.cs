﻿using GestionClinique.models;
using GestionClinique.repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionClinique.services
{
    public class CalendrierService : ICalendrierService
    {
        private ICalendrierRepository calendrierRepository;

        public CalendrierService(ICalendrierRepository calendrierRepository)
        {
            this.calendrierRepository = calendrierRepository;
        }

        public void ajouterCalendrier(Calendrier calendrier)
        {
            calendrierRepository.save(calendrier);
        }
    }
}
