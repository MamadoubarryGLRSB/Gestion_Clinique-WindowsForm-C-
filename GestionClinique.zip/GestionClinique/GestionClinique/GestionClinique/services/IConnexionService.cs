﻿using GestionClinique.models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionClinique.services
{
    public interface IConnexionService
    {
        User seConnecter(string login, string password);
        List<User> listerMedecin();
        User finfById(int id);
        Rp finfByIdRp(int id);
    }
}
