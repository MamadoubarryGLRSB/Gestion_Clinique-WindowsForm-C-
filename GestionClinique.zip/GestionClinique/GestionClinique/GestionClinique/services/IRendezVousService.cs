﻿using GestionClinique.dto;
using GestionClinique.models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Lifetime;
using System.Text;
using System.Threading.Tasks;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ToolTip;

namespace GestionClinique.services
{
    public interface IRendezVousService
    {
        List<RendezVous> listerRdV();
        List<RendezVous> listerRdVMedecin(User user, string date);
        List<RendezVous> listerRdVRp(User user, string date);
        List<RendezVous> listerConsultationBydate(string date);
        bool saveRdv(RendezVous rendezVous);
        void ajouterRdv(RendezVous rendezVous);
        void annulerRdv(RendezVous rendezVous);
        RendezVous Search(string date, string heure, User user);
        RendezVous SearchRp(string date, string heure, User user);


    }
}
