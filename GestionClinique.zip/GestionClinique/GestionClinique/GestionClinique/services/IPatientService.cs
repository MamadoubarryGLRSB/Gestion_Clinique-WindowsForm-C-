﻿using GestionClinique.dto;
using GestionClinique.models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ToolTip;

namespace GestionClinique.services
{
    public interface IPatientService
    {
        List<PatientDto> listerPatient();
        List<Patient> listerPatientP();
        void ajouterPatient(Patient patient);
       void modifierPatient(Patient patient);
       void supprimerPatient(int id);
        Patient finfById(int id);
    }
}
