﻿using GestionClinique.models;
using GestionClinique.repository;
using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionClinique.services
{
    public class RendezVousService : IRendezVousService
    {
        //Couplage faible
        private IRendezVousRepository rendezVousRepository;

        public RendezVousService()
        {
        }

        public RendezVousService(IRendezVousRepository rendezVousRepository)
        {
            this.rendezVousRepository = rendezVousRepository;
        }

        public void ajouterRdv(RendezVous rendezVous)
        {
            rendezVousRepository.save(rendezVous);
        }

        public void annulerRdv(RendezVous rendezVous)
        {
            rendezVousRepository.update(rendezVous);
        }

        public List<RendezVous> listerConsultationBydate(string date)
        {
            return rendezVousRepository.findByLibelle(date);
        }

        public List<RendezVous> listerRdV()
        {
            return rendezVousRepository.findAll();
        }

        public List<RendezVous> listerRdVMedecin(User user, string date)
        {
            return rendezVousRepository.findAllMedecin(user,date);
        }

        public List<RendezVous> listerRdVRp(User user, string date)
        {
            return rendezVousRepository.findAllRp(user,date);
        }

        public bool saveRdv(RendezVous rendezVous)
        {
            throw new NotImplementedException();
        }

        public RendezVous Search(string date, string heure, User user)
        {
           return rendezVousRepository.search(date, heure, user);
        }

        public RendezVous SearchRp(string date, string heure, User user)
        {
            return rendezVousRepository.searchRp(date, heure, user);
        }
    }
}
