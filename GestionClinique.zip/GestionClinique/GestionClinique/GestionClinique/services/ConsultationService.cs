﻿using GestionClinique.dto;
using GestionClinique.models;
using GestionClinique.repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionClinique.services
{
    public class ConsultationService : IConsultationService
    {
        //Couplage faible
        private IConsultationRepository consultationRepository;

        public ConsultationService(IConsultationRepository consultationRepository)
        {
            this.consultationRepository = consultationRepository;
        }

        public void ajouterConsultation(Consultation consultation)
        {
            consultationRepository.save(consultation);
        }

        public Consultation finfById(int id)
        {
            return consultationRepository.findById(id);
        }

        public List<ConsultationDto> listerConsultationBydate(string date)
        {
            return consultationRepository.findByLibelle(date);
        }

        public List<ConsultationDto> listerConsultationPatient(Patient patient)
        {
            return consultationRepository.findByLibellePatient(patient);
        }

        public List<ConsultationDto> listerRdVConsultation()
        {
            return consultationRepository.findAll();
        }

        public DetailDto listerRdVConsultationD(int id)
        {
           return consultationRepository.findAllD(id);
        }
    }
}
