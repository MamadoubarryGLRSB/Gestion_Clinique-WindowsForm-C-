﻿using GestionClinique.models;
using GestionClinique.repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionClinique.services
{
    public class MedicamentService : IMedicamentService
    {
        private IMedicamentRepository medicamentRepository;

        public MedicamentService(IMedicamentRepository medicamentRepository)
        {
            this.medicamentRepository = medicamentRepository;
        }

        public void ajouterPatient(Medicaments medicaments)
        {
            medicamentRepository.save(medicaments);
        }

        public List<Medicaments> listerMedicaments()
        {
          return medicamentRepository.findAll();
        }
    }
}
