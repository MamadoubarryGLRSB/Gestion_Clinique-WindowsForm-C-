﻿using GestionClinique.dto;
using GestionClinique.models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionClinique.services
{
    public interface IConsultationService
    {
        List<ConsultationDto> listerRdVConsultation();
        DetailDto listerRdVConsultationD(int id);

        List<ConsultationDto> listerConsultationBydate(string date);
        List<ConsultationDto> listerConsultationPatient(Patient patient);
        void ajouterConsultation(Consultation consultation);
        Consultation finfById(int id);
    }
}
