﻿using GestionClinique.models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ToolTip;
using GestionClinique.dto;

namespace GestionClinique.repository
{
    public class UserRepository :BaseRepository,IUserRepository
    {
        private readonly string SQL_SELECT_BY_Login = @"select * from users where login like '%'+@login+'%'";
        private readonly string SQL_SELECT_ALL = @"select * from users where role like 'medecin' or role like 'rp'";
        private readonly string SQL_FIND_BY_ID = "select * from users where id=@id";
        private readonly string SQL_SELECT_BY_ID_RP = @"select * from users where role like 'rp' and id=@id";
        public UserRepository(string connexionString)
        {
            ConnexionString= connexionString;
        }

        public List<User> findAll()
        {
            List<User> users = new List<User>();
            //Ouvrir la connexion
            using (var connection = new SqlConnection(ConnexionString))
            using (var command = new SqlCommand())
            {
                try
                {
                    connection.Open();
                    command.Connection = connection;
                    //2-Prepare la requette
                    command.CommandText = SQL_SELECT_ALL;
                    //3-Execution de la requette
                    SqlDataReader dr = command.ExecuteReader();
                    //4-Parcours de la requette
                    while (dr.Read())
                    {
                      
                        //Mapping relationnel objet
                        User user = new User()
                        {

                            Id = (int)dr[0],
                            NomComplet = dr[3].ToString(),
                          
                            Type = dr[5].ToString()
                        };
                        Enum.TryParse(dr[4].ToString(), out Role role);
                        user.Role = role;

                        users.Add(user);
                    }
                    dr.Close();

                }
                catch (Exception ex)
                {
                    throw ex;

                }
                finally
                {
                    command.Dispose();
                    //-5 Fermeture de la Connexion
                    connection.Close();

                }
            }
            return users;
        }

        public User findById(int id)
        {
            User user = null;
            //Ouvrir la connexion
            using (var connection = new SqlConnection(ConnexionString))
            using (var command = new SqlCommand())
            {
                try
                {
                    connection.Open();
                    command.Connection = connection;
                    //2-Prepare la requette
                    command.CommandText = SQL_FIND_BY_ID;
                    //-Changer les parametres par leurs valeurs
                    command.Parameters.Add("@id", SqlDbType.Int).Value = id;
                    //3-Execution de la requette
                    SqlDataReader dr = command.ExecuteReader();
                    //4-Parcours de la requette
                    if (dr.Read())
                    {
                        //Mapping relationnel objet
                        user = new User()
                        {

                            Id = (int)dr[0],
                            NomComplet = dr[3].ToString(),

                            Type = dr[5].ToString()


                        };
                        Enum.TryParse(dr[4].ToString(), out Role role);
                        user.Role = role;


                    }
                    dr.Close();

                }
                catch (Exception ex)
                {
                    throw ex;

                }
                finally
                {
                    command.Dispose();
                    //-5 Fermeture de la Connexion
                    connection.Close();

                }
            }
            return user;
        }

        public Rp findByIdRp(int id)
        {
            Rp rp = null;

            //Ouvrir la connexion
            using (var connection = new SqlConnection(ConnexionString))
            using (var command = new SqlCommand())
            {
                try
                {
                    connection.Open();
                    command.Connection = connection;
                    //2-Prepare la requette
                    command.CommandText = SQL_SELECT_BY_ID_RP;
                    //-Changer les parametres par leurs valeurs
                    command.Parameters.Add("@id", SqlDbType.Int).Value = id;

                    //3-Execution de la requette
                    command.ExecuteNonQuery();
                    SqlDataReader dr = command.ExecuteReader();
                    //4-Parcours de la requette
                    if (dr.Read())
                    {
                        //Mapping relationnel objet
                        rp = new Rp()
                        {
                            Id = (int)dr[0],
                            Login = dr[1].ToString(),
                            Password = dr[2].ToString(),
                            NomComplet = dr[3].ToString(),

                            Type = dr[5].ToString(),

                        };


                    }
                    dr.Close();


                }
                catch (Exception ex)
                {
                    throw ex;

                }
                finally
                {
                    command.Dispose();
                    //-5 Fermeture de la Connexion
                    connection.Close();

                }

            }
            return rp;

        }

        public User FindByLogin(string login)
        {

            User user = null;
            //Ouvrir la connexion
            using (var connection = new SqlConnection(ConnexionString))
            using (var command = new SqlCommand())
            {
                try
                {
                    connection.Open();
                    command.Connection = connection;
                    //2-Prepare la requette
                    command.CommandText = SQL_SELECT_BY_Login;
                    //-Changer les parametres par leurs valeurs
                    command.Parameters.Add("@login", SqlDbType.NVarChar).Value =login;
                    //3-Execution de la requette
                    SqlDataReader dr = command.ExecuteReader();
                    //4-Parcours de la requette
                    if (dr.Read())
                    {
                        //Mapping relationnel objet
                         user = new User()
                        {
                            Id = (int)dr[0],
                            Login = dr[1].ToString(),
                            Password = dr[2].ToString(),
                             NomComplet = dr[3].ToString(),
                            
                             Type= dr[5].ToString(),

                        };
                        Enum.TryParse(dr[4].ToString(), out Role role);
                        user.Role = role;
                        
                    }
                    dr.Close();

                }
                catch (Exception ex)
                {
                    throw ex;

                }
                finally
                {
                    command.Dispose();
                    //-5 Fermeture de la Connexion
                    connection.Close();

                }
            }
            return user;
        }
    }
}
