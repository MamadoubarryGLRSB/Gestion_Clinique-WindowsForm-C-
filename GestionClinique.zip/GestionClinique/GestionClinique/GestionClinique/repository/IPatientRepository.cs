﻿using GestionClinique.dto;
using GestionClinique.models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionClinique.repository
{
    public interface IPatientRepository
    {
        List<PatientDto> findAll();
        List<Patient> findAllP();
        void save(Patient patient);
        void edit(Patient patient);
        void delete(int id);
        Patient findById(int id);
    }
}
