﻿using GestionClinique.dto;
using GestionClinique.models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionClinique.repository
{
    public class PrestationRepository : BaseRepository, IPrestationRepository
    {
        private readonly string SQL_SELECT_ALL = @"select * from prestation where date=CAST(GETDATE() AS DATE)";
        private readonly string SQL_INSERT = @"insert into prestation(date,patient_id,constantes) values(@date,@patient_id,@constantes)";
        private readonly string SQL_SELECT_DATE = @"select * from prestation where date=@date";
        private readonly string SQL_SELECT_Patient = @"select * from prestation where patient_id=@patient_id";
        private readonly string SQL_FIND_BY_ID = "select * from prestation where id=@id";

        private IPatientRepository patientRepository;
        public PrestationRepository(string connexionString, IPatientRepository patientRepository)
        {
            ConnexionString = connexionString;
            this.patientRepository = patientRepository;
        }

        public List<PrestationDto> findAll()
        {
            List<PrestationDto> prestations = new List<PrestationDto>();
            //Ouvrir la connexion
            using (var connection = new SqlConnection(ConnexionString))
            using (var command = new SqlCommand())
            {
                try
                {
                    connection.Open();
                    command.Connection = connection;
                    //2-Prepare la requette
                    command.CommandText = SQL_SELECT_ALL;
                    //3-Execution de la requette
                    SqlDataReader dr = command.ExecuteReader();
                    //4-Parcours de la requette
                    while (dr.Read())
                    {
                        int id = (int)dr[4];
                        //Mapping relationnel objet
                        PrestationDto prestation = new PrestationDto()
                        {

                            Id = (int)dr[0],
                            Date = dr[1].ToString(),
                            Heure = dr[2].ToString(),
                          
                            Patient = patientRepository.findById(id)


                            //Medecin=userrepo.findibyId( (int)dr[0]
                        };

                        prestations.Add(prestation);
                    }
                    dr.Close();

                }
                catch (Exception ex)
                {
                    throw ex;

                }
                finally
                {
                    command.Dispose();
                    //-5 Fermeture de la Connexion
                    connection.Close();

                }
            }
            return prestations;
        }

        public Prestation findById(int id)
        {
            Prestation prestation = null;
            //Ouvrir la connexion
            using (var connection = new SqlConnection(ConnexionString))
            using (var command = new SqlCommand())
            {
                try
                {
                    connection.Open();
                    command.Connection = connection;
                    //2-Prepare la requette
                    command.CommandText = SQL_FIND_BY_ID;
                    //-Changer les parametres par leurs valeurs
                    command.Parameters.Add("@id", SqlDbType.Int).Value = id;
                    //3-Execution de la requette
                    SqlDataReader dr = command.ExecuteReader();
                    //4-Parcours de la requette
                    if (dr.Read())
                    {
                        //Mapping relationnel objet
                        prestation = new Prestation()
                        {

                            Id = (int)dr[0],
                            Date = dr[1].ToString(),
                            Constantes = dr[5].ToString(),
                            Patient = patientRepository.findById((int)dr[4]),



                            //Medecin=userrepo.findibyId( (int)dr[0])


                        };


                    }
                    dr.Close();

                }
                catch (Exception ex)
                {
                    throw ex;

                }
                finally
                {
                    command.Dispose();
                    //-5 Fermeture de la Connexion
                    connection.Close();

                }
            }
            return prestation;
        }

        public List<PrestationDto> findByLibelle(string date)
        {
            List<PrestationDto> prestations = new List<PrestationDto>();
            //Ouvrir la connexion
            using (var connection = new SqlConnection(ConnexionString))
            using (var command = new SqlCommand())
            {
                try
                {
                    connection.Open();
                    command.Connection = connection;
                    //2-Prepare la requette
                    command.CommandText = SQL_SELECT_DATE;
                    //-Changer les parametres par leurs valeurs
                    command.Parameters.Add("@date", SqlDbType.Date).Value = date;
                    //3-Execution de la requette
                    SqlDataReader dr = command.ExecuteReader();
                    //4-Parcours de la requette
                    while (dr.Read())
                    {
                        int id = (int)dr[4];
                        //Mapping relationnel objet
                        PrestationDto prestation = new PrestationDto()
                        {
                            Id = (int)dr[0],
                            Date = dr[1].ToString(),
                            Heure = dr[2].ToString(),
                            
                            Patient = patientRepository.findById(id)

                        };
                        prestations.Add(prestation);
                    }
                    dr.Close();

                }
                catch (Exception ex)
                {
                    throw ex;

                }
                finally
                {
                    command.Dispose();
                    //-5 Fermeture de la Connexion
                    connection.Close();

                }
            }
            return prestations; 
        }

        public List<PrestationDto> findByLibellePatient(Patient patient)
        {
            List<PrestationDto> prestations = new List<PrestationDto>();
            //Ouvrir la connexion
            using (var connection = new SqlConnection(ConnexionString))
            using (var command = new SqlCommand())
            {
                try
                {
                    connection.Open();
                    command.Connection = connection;
                    //2-Prepare la requette
                    command.CommandText = SQL_SELECT_Patient;
                    //-Changer les parametres par leurs valeurs
                    command.Parameters.Add("@patient_id", SqlDbType.Int).Value = patient.Id;
                    //3-Execution de la requette
                    SqlDataReader dr = command.ExecuteReader();
                    //4-Parcours de la requette
                    while (dr.Read())
                    {
                        int id = (int)dr[4];
                        //Mapping relationnel objet
                        PrestationDto prestation = new PrestationDto()
                        {
                            Id = (int)dr[0],
                            Date = dr[1].ToString(),
                            Heure = dr[2].ToString(),
                           
                            Patient = patientRepository.findById(id)

                        };
                        prestations.Add(prestation);
                    }
                    dr.Close();

                }
                catch (Exception ex)
                {
                    throw ex;

                }
                finally
                {
                    command.Dispose();
                    //-5 Fermeture de la Connexion
                    connection.Close();

                }
            }
            return prestations;
        }

        public void save(Prestation prestation)
        {
            //Ouvrir la connexion
            using (var connection = new SqlConnection(ConnexionString))
            using (var command = new SqlCommand())
            {
                try
                {
                    connection.Open();
                    command.Connection = connection;
                    //2-Prepare la requette
                    command.CommandText = SQL_INSERT;
                    //-Changer les parametres par leurs valeurs
                    command.Parameters.Add("@date", SqlDbType.DateTime).Value = prestation.Date;
                    command.Parameters.Add("@constantes", SqlDbType.NVarChar).Value = prestation.Constantes;
                    command.Parameters.Add("@patient_id", SqlDbType.Int).Value = prestation.Patient.Id;
                    //3-Execution de la requette
                    command.ExecuteNonQuery();

                    
                    //3-Execution de la requette
                }
                catch (Exception ex)
                {
                    throw ex;

                }
                finally
                {
                    command.Dispose();
                    //-5 Fermeture de la Connexion
                    connection.Close();

                }
            }
        }
    }
}
