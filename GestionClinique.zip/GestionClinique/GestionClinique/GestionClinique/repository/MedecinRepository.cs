﻿using GestionClinique.models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GestionClinique.dto;

namespace GestionClinique.repository
{
    public class MedecinRepository :BaseRepository, IMedecinRepository
    {
        private readonly string SQL_SELECT_BY_ID = @"select * from users where role like 'medecin' and id=@id";
        private readonly string SQL_SELECT_ALL = @"select * from users where role like 'medecin' ";
        private readonly string SQL_SELECT_ALL_J = @"select * from users u,Planning p  where role like 'medecin' and p.medecin_id=u.id and p.jour like '%'+@jour+'%'";
        public MedecinRepository(string connexionString)
        {
            ConnexionString = connexionString;
        }

        public List<Medecin> findAll()
        {
            List<Medecin> medecins = new List<Medecin>();
            //Ouvrir la connexion
            using (var connection = new SqlConnection(ConnexionString))
            using (var command = new SqlCommand())
            {
                try
                {
                    connection.Open();
                    command.Connection = connection;
                    //2-Prepare la requette
                    command.CommandText = SQL_SELECT_ALL;
                    //3-Execution de la requette
                    SqlDataReader dr = command.ExecuteReader();
                    //4-Parcours de la requette
                    while (dr.Read())
                    {
                        //Mapping relationnel objet
                        Medecin medecin = new Medecin()
                        {

                            Id = (int)dr[0],
                            NomComplet = dr[3].ToString(),
                            TypeMedecin= dr[5].ToString(),


                        };
                        medecins.Add(medecin);
                    }
                    dr.Close();

                }
                catch (Exception ex)
                {
                    throw ex;

                }
                finally
                {
                    command.Dispose();
                    //-5 Fermeture de la Connexion
                    connection.Close();

                }
            }
            return medecins;
        }

        public List<Medecin> findAllM(string jour)
        {
            List<Medecin> medecins = new List<Medecin>();
            //Ouvrir la connexion
            using (var connection = new SqlConnection(ConnexionString))
            using (var command = new SqlCommand())
            {
                try
                {
                    connection.Open();
                    command.Connection = connection;
                    //2-Prepare la requette
                    command.CommandText = SQL_SELECT_ALL_J;
                    //3-Execution de la requette
                    //-Changer les parametres par leurs valeurs
                    command.Parameters.Add("@jour", SqlDbType.Int).Value = jour;

                    SqlDataReader dr = command.ExecuteReader();
                    //4-Parcours de la requette
                    while (dr.Read())
                    {
                        //Mapping relationnel objet
                        Medecin medecin = new Medecin()
                        {

                            Id = (int)dr[0],
                            NomComplet = dr[3].ToString(),
                            TypeMedecin = dr[5].ToString(),


                        };
                        medecins.Add(medecin);
                    }
                    dr.Close();

                }
                catch (Exception ex)
                {
                    throw ex;

                }
                finally
                {
                    command.Dispose();
                    //-5 Fermeture de la Connexion
                    connection.Close();

                }
            }
            return medecins;
        }

        public Medecin findById(int id)
        {
            Medecin medecin=null;

            //Ouvrir la connexion
            using (var connection = new SqlConnection(ConnexionString))
            using (var command = new SqlCommand())
            {
                try
                {
                    connection.Open();
                    command.Connection = connection;
                    //2-Prepare la requette
                    command.CommandText = SQL_SELECT_BY_ID;
                    //-Changer les parametres par leurs valeurs
                    command.Parameters.Add("@id", SqlDbType.Int).Value = id;

                    //3-Execution de la requette
                    command.ExecuteNonQuery();
                    SqlDataReader dr = command.ExecuteReader();
                    //4-Parcours de la requette
                    if (dr.Read())
                    {
                        //Mapping relationnel objet
                        medecin = new Medecin()
                        {
                            Id = (int)dr[0],
                            Login = dr[1].ToString(),
                            Password = dr[2].ToString(),
                            NomComplet = dr[3].ToString(),
                            
                            Type = dr[5].ToString(),

                        };
                        

                    }
                    dr.Close();


                }
                catch (Exception ex)
                {
                    throw ex;

                }
                finally
                {
                    command.Dispose();
                    //-5 Fermeture de la Connexion
                    connection.Close();

                }
                
            }
            return medecin;

        }
    }
}
