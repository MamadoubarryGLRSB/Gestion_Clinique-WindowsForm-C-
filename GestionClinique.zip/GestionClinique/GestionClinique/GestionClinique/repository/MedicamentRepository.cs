﻿using GestionClinique.dto;
using GestionClinique.models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionClinique.repository
{
    public class MedicamentRepository:BaseRepository, IMedicamentRepository
    {
        private readonly string SQL_SELECT_ALL = @"select * from Medicament";
        private readonly string SQL_INSERT = @"insert into Medicament(type)values(@type)";
        public MedicamentRepository(string connexionString)
        {
            ConnexionString = connexionString;
        }

        public List<Medicaments> findAll()
        {

            List<Medicaments> medicaments = new List<Medicaments>();
            //Ouvrir la connexion
            using (var connection = new SqlConnection(ConnexionString))
            using (var command = new SqlCommand())
            {
                try
                {
                    connection.Open();
                    command.Connection = connection;
                    //2-Prepare la requette
                    command.CommandText = SQL_SELECT_ALL;
                    //3-Execution de la requette
                    SqlDataReader dr = command.ExecuteReader();
                    //4-Parcours de la requette
                    while (dr.Read())
                    {
                        //Mapping relationnel objet
                        Medicaments medicament = new Medicaments()
                        {

                            Id = (int)dr[0],
                            Type = dr[1].ToString(),
                            

                        };
                        medicaments.Add(medicament);
                    }
                    dr.Close();

                }
                catch (Exception ex)
                {
                    throw ex;

                }
                finally
                {
                    command.Dispose();
                    //-5 Fermeture de la Connexion
                    connection.Close();

                }
            }
            return medicaments;
        }

        public void save(Medicaments medicament)
        {
            //Ouvrir la connexion
            using (var connection = new SqlConnection(ConnexionString))
            using (var command = new SqlCommand())
            {
                try
                {
                    connection.Open();
                    command.Connection = connection;
                    //2-Prepare la requette
                    command.CommandText = SQL_INSERT;
                    //-Changer les parametres par leurs valeurs
                    command.Parameters.Add("@type", SqlDbType.NVarChar).Value = medicament.Type;
                   


                    //3-Execution de la requette
                    command.ExecuteNonQuery();


                }
                catch (Exception ex)
                {
                    throw ex;

                }
                finally
                {
                    command.Dispose();
                    //-5 Fermeture de la Connexion
                    connection.Close();

                }
            }
        }
    }
}
