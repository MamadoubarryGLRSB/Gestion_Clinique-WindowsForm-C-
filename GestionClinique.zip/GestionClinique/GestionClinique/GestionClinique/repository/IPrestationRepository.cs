﻿using GestionClinique.dto;
using GestionClinique.models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionClinique.repository
{
    public interface IPrestationRepository
    {
        List<PrestationDto> findAll();
        List<PrestationDto> findByLibelle(string date);
        List<PrestationDto> findByLibellePatient(Patient patient);
        void save(Prestation prestation);
        Prestation findById(int id);
    }
}
