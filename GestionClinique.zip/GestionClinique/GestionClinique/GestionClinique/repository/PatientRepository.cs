﻿using GestionClinique.dto;
using GestionClinique.models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ToolTip;

namespace GestionClinique.repository
{
    public class PatientRepository :BaseRepository,IPatientRepository
    {
        private readonly string SQL_SELECT_ALL = @"select * from patient";
        private readonly string SQL_INSERT = @"insert into patient(nom,prenom,code,antecedents,sexe,DateNaissance,adresse,telephone)values(@nom,@prenom,@code,@antecedents,@sexe,@DateNaissance,@adresse,@telephone)";
        private readonly string SQL_DELETE = @"delete  from patient where id=@id";
        private readonly string SQL_UPDATE = @"update patient set nom=@nom,prenom=@prenom,code=@code where id=@id";
        private readonly string SQL_FIND_BY_ID = "select * from patient where id=@id";
        public PatientRepository(string connexionString)
        {
            ConnexionString = connexionString;
        }

        public void delete(int id)
        {
            //Ouvrir la connexion
            using (var connection = new SqlConnection(ConnexionString))
            using (var command = new SqlCommand())
            {
                try
                {
                    connection.Open();
                    command.Connection = connection;
                    //2-Prepare la requette
                    command.CommandText = SQL_DELETE;
                    //-Changer les parametres par leurs valeurs
                    command.Parameters.Add("@id", SqlDbType.Int).Value = id;

                    //3-Execution de la requette
                    command.ExecuteNonQuery();


                }
                catch (Exception ex)
                {
                    throw ex;

                }
                finally
                {
                    command.Dispose();
                    //-5 Fermeture de la Connexion
                    connection.Close();

                }
            }
        }

        public void edit(Patient patient)
        {
            //Ouvrir la connexion
            using (var connection = new SqlConnection(ConnexionString))
            using (var command = new SqlCommand())
            {
                try
                {
                    connection.Open();
                    command.Connection = connection;
                    //2-Prepare la requette
                    command.CommandText = SQL_UPDATE;
                    //-Changer les parametres par leurs valeurs
                    command.Parameters.Add("@nom", SqlDbType.NVarChar).Value = patient.Nom;
                    command.Parameters.Add("@prenom", SqlDbType.NVarChar).Value = patient.Prenom;
                    command.Parameters.Add("@code", SqlDbType.NVarChar).Value = patient.Code;
                    command.Parameters.Add("@id", SqlDbType.Int).Value = patient.Id;

                    //3-Execution de la requette
                    command.ExecuteNonQuery();


                }
                catch (Exception ex)
                {
                    throw ex;

                }
                finally
                {
                    command.Dispose();
                    //-5 Fermeture de la Connexion
                    connection.Close();

                }
            }
        }

        public List<PatientDto> findAll()
        {
            List<PatientDto> patients = new List<PatientDto>();
            //Ouvrir la connexion
            using (var connection = new SqlConnection(ConnexionString))
            using (var command = new SqlCommand())
            {
                try
                {
                    connection.Open();
                    command.Connection = connection;
                    //2-Prepare la requette
                    command.CommandText = SQL_SELECT_ALL;
                    //3-Execution de la requette
                    SqlDataReader dr = command.ExecuteReader();
                    //4-Parcours de la requette
                    while (dr.Read())
                    {
                        //Mapping relationnel objet
                        PatientDto patient = new PatientDto()
                        {

                             Id = (int)dr[0],
                             Nom= dr[1].ToString(),
                             Prenom= dr[2].ToString(),
                            
                             
                            

                            //Medecin=userrepo.findibyId( (int)dr[0])


                        };
                        patients.Add(patient);
                    }
                    dr.Close();

                }
                catch (Exception ex)
                {
                    throw ex;

                }
                finally
                {
                    command.Dispose();
                    //-5 Fermeture de la Connexion
                    connection.Close();

                }
            }
            return patients;
        }

        public List<Patient> findAllP()
        {
            List<Patient> patients = new List<Patient>();
            //Ouvrir la connexion
            using (var connection = new SqlConnection(ConnexionString))
            using (var command = new SqlCommand())
            {
                try
                {
                    connection.Open();
                    command.Connection = connection;
                    //2-Prepare la requette
                    command.CommandText = SQL_SELECT_ALL;
                    //3-Execution de la requette
                    SqlDataReader dr = command.ExecuteReader();
                    //4-Parcours de la requette
                    while (dr.Read())
                    {
                        //Mapping relationnel objet
                        Patient patient = new Patient()
                        {

                            Id = (int)dr[0],
                            Nom = dr[1].ToString(),
                            Prenom = dr[2].ToString(),




                            //Medecin=userrepo.findibyId( (int)dr[0])


                        };
                        patients.Add(patient);
                    }
                    dr.Close();

                }
                catch (Exception ex)
                {
                    throw ex;

                }
                finally
                {
                    command.Dispose();
                    //-5 Fermeture de la Connexion
                    connection.Close();

                }
            }
            return patients;
        }

        public Patient findById(int id)
        {
            Patient patient = null;
            //Ouvrir la connexion
            using (var connection = new SqlConnection(ConnexionString))
            using (var command = new SqlCommand())
            {
                try
                {
                    connection.Open();
                    command.Connection = connection;
                    //2-Prepare la requette
                    command.CommandText = SQL_FIND_BY_ID;
                    //-Changer les parametres par leurs valeurs
                    command.Parameters.Add("@id", SqlDbType.Int).Value = id;
                    //3-Execution de la requette
                    SqlDataReader dr = command.ExecuteReader();
                    //4-Parcours de la requette
                    if (dr.Read())
                    {
                        //Mapping relationnel objet
                        patient = new Patient()
                        {

                            Id = (int)dr[0],
                            Nom = dr[1].ToString(),
                            Prenom = dr[2].ToString(),
                            Code = dr[3].ToString(),
                            Antecedent = dr[4].ToString() ,
                            Sexe= dr[5].ToString(),
                            Date_Naissance= dr[6].ToString(),
                            Adresse= dr[7].ToString(),
                            Telephone= dr[8].ToString(),


                            //Medecin=userrepo.findibyId( (int)dr[0])


                        };
                    

                    }
                    dr.Close();

                }
                catch (Exception ex)
                {
                    throw ex;

                }
                finally
                {
                    command.Dispose();
                    //-5 Fermeture de la Connexion
                    connection.Close();

                }
            }
            return patient;
        }

        public void save(Patient patient)
        {
            //Ouvrir la connexion
            using (var connection = new SqlConnection(ConnexionString))
            using (var command = new SqlCommand())
            {
                try
                {
                    connection.Open();
                    command.Connection = connection;
                    //2-Prepare la requette
                    command.CommandText = SQL_INSERT;
                    //-Changer les parametres par leurs valeurs
                    command.Parameters.Add("@nom", SqlDbType.NVarChar).Value = patient.Nom;
                    command.Parameters.Add("@prenom", SqlDbType.NVarChar).Value = patient.Prenom;
                    command.Parameters.Add("@code", SqlDbType.NVarChar).Value = patient.Code;
                    command.Parameters.Add("@sexe", SqlDbType.NVarChar).Value = patient.Sexe;
                    command.Parameters.Add("@DateNaissance", SqlDbType.NVarChar).Value = patient.Date_Naissance;
                    command.Parameters.Add("@adresse", SqlDbType.NVarChar).Value = patient.Adresse;
                    command.Parameters.Add("@telephone", SqlDbType.NVarChar).Value = patient.Telephone;
                    command.Parameters.Add("@antecedents", SqlDbType.NVarChar).Value = patient.Antecedent;
                    //3-Execution de la requette
                    command.ExecuteNonQuery();


                }
                catch (Exception ex)
                {
                    throw ex;

                }
                finally
                {
                    command.Dispose();
                    //-5 Fermeture de la Connexion
                    connection.Close();

                }
            }
        }

        
    }
}
