﻿using GestionClinique.dto;
using GestionClinique.models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ToolTip;

namespace GestionClinique.repository
{
    public interface IConsultationRepository
    {
        List<ConsultationDto> findAll();
         DetailDto findAllD(int id);
        Consultation findById(int id);
        List<ConsultationDto> findByLibelle(string date);
        List<ConsultationDto> findByLibellePatient(Patient patient);
        void save(Consultation consultation);
    }
}
