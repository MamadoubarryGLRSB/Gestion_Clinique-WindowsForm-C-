﻿using GestionClinique.dto;
using GestionClinique.models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ToolTip;

namespace GestionClinique.repository
{
    public class RendezVousRepository : BaseRepository, IRendezVousRepository
    {
        private readonly string SQL_SELECT_ALL_MEDECIN = @"select * from rendezvous where date=@date and medecin_id=@medecin_id";
        private readonly string SQL_SELECT_ALL = @"select * from rendezvous where date=CAST(GETDATE() AS DATE)";
        private readonly string SQL_INSERT = @"insert into rendezvous(type,date,heure,etat,patient_id,user_id) values(@type,@date,@heure,@etat,@patient_id,@user_id)";
        private readonly string SQL_UPDATE = @"update rendezvous set etat=@etat where id=@id";
        private readonly string SQL_SELECT_DATE = @"select * from rendezvous where date=@date";
        private readonly string SQL_SELECT_ALL_RP = @"select * from rendezvous where date=@date and rp_id=@rp_id";
        private readonly string SELECT_RRDV = "select r.* from rendezvous r,users u where r.medecin_id=u.id and r.heure=@heure and r.date=@date and u.id=@id";
        private readonly string SELECT_RRDV_RP = "select r.* from rendezvous r,users u where r.rp_id=u.id and r.heure=@heure and r.date=@date and u.id=@id";
        private IPatientRepository patientRepository;
        private IUserRepository userRepository;
       
        public RendezVousRepository(string connexionString, IPatientRepository patientRepository, IUserRepository userRepository)
        {
            ConnexionString = connexionString;
            this.patientRepository = patientRepository;
            this.userRepository = userRepository;
        }

        public List<RendezVous> findAll()
        {
            List<RendezVous> rendezVous = new List<RendezVous>();
            //Ouvrir la connexion
            using (var connection = new SqlConnection(ConnexionString))
            using (var command = new SqlCommand())
            {
                try
                {
                    connection.Open();
                    command.Connection = connection;
                    //2-Prepare la requette
                    command.CommandText = SQL_SELECT_ALL;
                    //3-Execution de la requette
                    SqlDataReader dr = command.ExecuteReader();
                    
                    //4-Parcours de la requette
                    while (dr.Read())
                    {
                        int id = (int)dr[5];
                        int p = (int)dr[6];
                        //Mapping relationnel objet
                        RendezVous rdv = new RendezVous()
                        {

                            Id = (int)dr[0],
                            Type = dr[1].ToString(),
                            Date = dr[2].ToString(),
                            Heure = dr[3].ToString(),
                            Etat = dr[4].ToString(),
                            Patient = patientRepository.findById(id),
                            Medecin = userRepository.findById(p)
                            





                        


                        };
                        rendezVous.Add(rdv);
                    }
                    dr.Close();

                }
                catch (Exception ex)
                {
                    throw ex;

                }
                finally
                {
                    command.Dispose();
                    //-5 Fermeture de la Connexion
                    connection.Close();

                }
            }
            return rendezVous;
        }

        public List<RendezVous> findAllMedecin(User user,string date)
        {
            List<RendezVous> rendezVous = new List<RendezVous>();
            //Ouvrir la connexion
            using (var connection = new SqlConnection(ConnexionString))
            using (var command = new SqlCommand())
            {
                try
                {
                    connection.Open();
                    command.Connection = connection;


                    //2-Prepare la requette
                    command.CommandText = SQL_SELECT_ALL_MEDECIN;
                    //3-Execution de la requette
                    command.Parameters.Add("@date", SqlDbType.Date).Value = date;
                    command.Parameters.Add("@medecin_id", SqlDbType.Int).Value = user.Id;

                    SqlDataReader dr = command.ExecuteReader();

                    //4-Parcours de la requette
                    while (dr.Read())
                    {
                        int id = (int)dr[6];
                        //Mapping relationnel objet
                        RendezVous rdv = new RendezVous()
                        {

                            Id = (int)dr[0],
                            Type = dr[1].ToString(),
                            Date = dr[2].ToString(),
                            Heure = dr[3].ToString(),
                            Etat = dr[4].ToString(),
                            Patient = patientRepository.findById(id)




                        };
                        rendezVous.Add(rdv);
                    }
                    dr.Close();

                }
                catch (Exception ex)
                {
                    throw ex;

                }
                finally
                {
                    command.Dispose();
                    //-5 Fermeture de la Connexion
                    connection.Close();

                }
            }
            return rendezVous;
        }

        public List<RendezVous> findAllRp(User user, string date)
        {

            List<RendezVous> rendezVous = new List<RendezVous>();
            //Ouvrir la connexion
            using (var connection = new SqlConnection(ConnexionString))
            using (var command = new SqlCommand())
            {
                try
                {
                    connection.Open();
                    command.Connection = connection;
                    //2-Prepare la requette
                    command.CommandText = SQL_SELECT_ALL_RP;
                    //3-Execution de la requette
                    command.Parameters.Add("@date", SqlDbType.Date).Value = date;
                    command.Parameters.Add("@rp_id", SqlDbType.Int).Value = user.Id;
                    SqlDataReader dr = command.ExecuteReader();

                    //4-Parcours de la requette
                    while (dr.Read())
                    {
                        int id = (int)dr[6];
                        //Mapping relationnel objet
                        RendezVous rdv = new RendezVous()
                        {

                            Id = (int)dr[0],
                            Type = dr[1].ToString(),
                            Date = dr[2].ToString(),
                            Heure = dr[3].ToString(),
                            Etat = dr[4].ToString(),
                            Patient = patientRepository.findById(id)





                            //Medecin=userrepo.findibyId( (int)dr[0])



                        };
                        rendezVous.Add(rdv);
                    }
                    dr.Close();

                }
                catch (Exception ex)
                {
                    throw ex;

                }
                finally
                {
                    command.Dispose();
                    //-5 Fermeture de la Connexion
                    connection.Close();

                }
            }
            return rendezVous;
        }

        public List<RendezVous> findByLibelle(string date)
        {
            List<RendezVous> rendezVous = new List<RendezVous>();
            //Ouvrir la connexion
            using (var connection = new SqlConnection(ConnexionString))
            using (var command = new SqlCommand())
            {
                try
                {
                    connection.Open();
                    command.Connection = connection;
                    //2-Prepare la requette
                    command.CommandText = SQL_SELECT_DATE;
                    //-Changer les parametres par leurs valeurs
                    command.Parameters.Add("@date", SqlDbType.Date).Value = date;
                    //3-Execution de la requette
                    SqlDataReader dr = command.ExecuteReader();
                    //4-Parcours de la requette
                    while (dr.Read())
                    {
                        int id = (int)dr[6];
                        //Mapping relationnel objet
                        RendezVous rdv = new RendezVous()
                        {
                            Id = (int)dr[0],
                            Type = dr[1].ToString(),
                            Date = dr[2].ToString(),
                            Heure = dr[3].ToString(),
                            Etat = dr[4].ToString(),

                            Patient = patientRepository.findById(id)

                        };
                        rendezVous.Add(rdv);
                    }
                    dr.Close();

                }
                catch (Exception ex)
                {
                    throw ex;

                }
                finally
                {
                    command.Dispose();
                    //-5 Fermeture de la Connexion
                    connection.Close();

                }
            }
            return rendezVous;
        }

        public RendezVous search(string date, string heure, User user)
        {
            RendezVous rendezVous = null;
            //Ouvrir la connexion
            using (var connection = new SqlConnection(ConnexionString))
            using (var command = new SqlCommand())
            {
                try
                {
                    connection.Open();
                    command.Connection = connection;
                    //2-Prepare la requette
                    command.CommandText = SELECT_RRDV;
                    //-Changer les parametres par leurs valeurs
                    command.Parameters.Add("@date", SqlDbType.Date).Value = date;
                    command.Parameters.Add("@heure", SqlDbType.NVarChar).Value = heure;
                    command.Parameters.Add("@id", SqlDbType.Int).Value = user.Id;
                    //3-Execution de la requette
                    SqlDataReader dr = command.ExecuteReader();
                    //4-Parcours de la requette
                    if (dr.Read())
                    {
                        int id = (int)dr[6];
                        //Mapping relationnel objet
                        rendezVous = new RendezVous()
                        {

                            Id = (int)dr[0],
                            Type = dr[1].ToString(),
                            Date = dr[2].ToString(),
                            Heure = dr[3].ToString(),
                            Etat = dr[4].ToString(),

                            Patient = patientRepository.findById(id)


                        };


                    }
                    dr.Close();

                }
                catch (Exception ex)
                {
                    throw ex;

                }
                finally
                {
                    command.Dispose();
                    //-5 Fermeture de la Connexion
                    connection.Close();

                }
            }
            return rendezVous;
        }

        public void persit(RendezVous rendezVous)
        {
            throw new NotImplementedException();
        }

        public void save(RendezVous rendezVous)
        {
            //Ouvrir la connexion
            using (var connection = new SqlConnection(ConnexionString))
            using (var command = new SqlCommand())
            {
                try
                {
                    connection.Open();
                    command.Connection = connection;
                    //2-Prepare la requette
                    command.CommandText = SQL_INSERT;
                    //-Changer les parametres par leurs valeurs
                    command.Parameters.Add("@type", SqlDbType.NVarChar).Value = rendezVous.Type;
                    command.Parameters.Add("@date", SqlDbType.DateTime).Value = rendezVous.Date;
                    command.Parameters.Add("@heure", SqlDbType.NVarChar).Value = rendezVous.Heure;
                    command.Parameters.Add("@etat", SqlDbType.NVarChar).Value = rendezVous.Etat;
                    command.Parameters.Add("@patient_id", SqlDbType.Int).Value = rendezVous.Patient.Id;
                    command.Parameters.Add("@user_id", SqlDbType.Int).Value = rendezVous.Medecin.Id;


                    //3-Execution de la requette
                    command.ExecuteNonQuery();


                }
                catch (Exception ex)
                {
                    throw ex;

                }
                finally
                {
                    command.Dispose();
                    //-5 Fermeture de la Connexion
                    connection.Close();

                }
            }
        }

        public void update(RendezVous rendezVous)
        {
            //Ouvrir la connexion
            using (var connection = new SqlConnection(ConnexionString))
            using (var command = new SqlCommand())
            {
                try
                {
                    connection.Open();
                    command.Connection = connection;
                    //2-Prepare la requette
                    command.CommandText = SQL_UPDATE;
                    //-Changer les parametres par leurs valeurs
                    command.Parameters.Add("@etat", SqlDbType.NVarChar).Value = rendezVous.Etat;
                    command.Parameters.Add("@id", SqlDbType.Int).Value = rendezVous.Id;

                    //3-Execution de la requette
                    command.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    throw ex;

                }
                finally
                {
                    command.Dispose();
                    //-5 Fermeture de la Connexion
                    connection.Close();

                }
            }
        }

        public RendezVous searchRp(string date, string heure, User user)
        {
            RendezVous rendezVous = null;
            //Ouvrir la connexion
            using (var connection = new SqlConnection(ConnexionString))
            using (var command = new SqlCommand())
            {
                try
                {
                    connection.Open();
                    command.Connection = connection;
                    //2-Prepare la requette
                    command.CommandText = SELECT_RRDV_RP;
                    //-Changer les parametres par leurs valeurs
                    command.Parameters.Add("@date", SqlDbType.Date).Value = date;
                    command.Parameters.Add("@heure", SqlDbType.NVarChar).Value = heure;
                    command.Parameters.Add("@id", SqlDbType.Int).Value = user.Id;
                    //3-Execution de la requette
                    SqlDataReader dr = command.ExecuteReader();
                    //4-Parcours de la requette
                    if (dr.Read())
                    {
                        int id = (int)dr[6];
                        //Mapping relationnel objet
                        rendezVous = new RendezVous()
                        {

                            Id = (int)dr[0],
                            Type = dr[1].ToString(),
                            Date = dr[2].ToString(),
                            Heure = dr[3].ToString(),
                            Etat = dr[4].ToString(),

                            Patient = patientRepository.findById(id)


                        };


                    }
                    dr.Close();

                }
                catch (Exception ex)
                {
                    throw ex;

                }
                finally
                {
                    command.Dispose();
                    //-5 Fermeture de la Connexion
                    connection.Close();

                }
            }
            return rendezVous;
        }
    }
}
