﻿using GestionClinique.models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionClinique.repository
{
    public interface IUserRepository
    {
        User FindByLogin(string login);
        User findById(int id);
        List<User> findAll();
        Rp findByIdRp(int id);
    }
}
