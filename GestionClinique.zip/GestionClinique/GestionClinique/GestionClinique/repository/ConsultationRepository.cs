﻿using GestionClinique.dto;
using GestionClinique.models;
using GestionClinique.services;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ToolTip;

namespace GestionClinique.repository
{
    public class ConsultationRepository : BaseRepository, IConsultationRepository
    {
        private readonly string SQL_SELECT_ALL = @"select * from Consultation where date=CAST(GETDATE() AS DATE)";
        private readonly string SQL_INSERT = @"insert into Consultation(date,patient_id,constantes) values(@date,@patient_id,@constantes)";
        private readonly string SQL_SELECT_DATE =@"select * from Consultation where date=@date";
        private readonly string SQL_SELECT_Patient = @"select * from Consultation where patient_id=@patient_id";
        private readonly string SQL_SELECT_ALL_D = @"select * from Consultation where id=@id ";
        private readonly string SQL_FIND_BY_ID = "select * from Consultation where id=@id";
        private  IPatientRepository patientRepository;
        public ConsultationRepository(string connexionString, IPatientRepository patientRepository)
        {
            ConnexionString = connexionString;
            this.patientRepository= patientRepository;

        }
        public List<ConsultationDto> findAll()
        {
            List<ConsultationDto> consultations = new List<ConsultationDto>();
            //Ouvrir la connexion
            using (var connection = new SqlConnection(ConnexionString))
            using (var command = new SqlCommand())
            {
                try
                {
                    connection.Open();
                    command.Connection = connection;
                    //2-Prepare la requette
                    command.CommandText = SQL_SELECT_ALL;
                    //3-Execution de la requette
                    SqlDataReader dr = command.ExecuteReader();
                    //4-Parcours de la requette
                    while (dr.Read())
                    {
                        int id = (int)dr[6];
                        //Mapping relationnel objet
                        ConsultationDto consultation = new ConsultationDto()
                        {

                            Id = (int)dr[0],
                            Date =dr[1].ToString(),
                            //Constantes = dr[13].ToString(),




                            Patient = patientRepository.findById(id)
                            
                            
                            //Medecin=userrepo.findibyId( (int)dr[0]
                        };
                        
                        consultations.Add(consultation);
                    }
                    dr.Close();

                }
                catch (Exception ex)
                {
                    throw ex;

                }
                finally
                {
                    command.Dispose();
                    //-5 Fermeture de la Connexion
                    connection.Close();

                }
            }
            return consultations;
        }

        public DetailDto findAllD(int id)
        {
            DetailDto detailDto = null;
            //Ouvrir la connexion
            using (var connection = new SqlConnection(ConnexionString))
            using (var command = new SqlCommand())
            {
                try
                {
                    connection.Open();
                    command.Connection = connection;
                    //2-Prepare la requette
                    command.CommandText = SQL_SELECT_ALL_D;
                    //-Changer les parametres par leurs valeurs
                    command.Parameters.Add("@id", SqlDbType.Int).Value = id;

                    //3-Execution de la requette
                    command.ExecuteNonQuery();
                    SqlDataReader dr = command.ExecuteReader();
                    if (dr.Read())
                    {
                        //Mapping relationnel objet
                        detailDto = new DetailDto()
                        {
                            Id = (int)dr[0],
                            Date = dr[1].ToString(),
                            Time = dr[2].ToString(),
                            
                            //Tension = dr[4].ToString(),
                            //Poids = dr[5].ToString(),

                            Patient = patientRepository.findById((int)dr[6]),
                            //GroupeSanguin = dr[7].ToString()


                            //Medecin=userrepo.findibyId( (int)dr[0])


                        };


                    }
                    dr.Close();

                }
                catch (Exception ex)
                {
                    throw ex;

                }
                finally
                {
                    command.Dispose();
                    //-5 Fermeture de la Connexion
                    connection.Close();

                }
                return detailDto;
            }
        }

        public Consultation findById(int id)
        {
            Consultation consultation = null;
            //Ouvrir la connexion
            using (var connection = new SqlConnection(ConnexionString))
            using (var command = new SqlCommand())
            {
                try
                {
                    connection.Open();
                    command.Connection = connection;
                    //2-Prepare la requette
                    command.CommandText = SQL_FIND_BY_ID;
                    //-Changer les parametres par leurs valeurs
                    command.Parameters.Add("@id", SqlDbType.Int).Value = id;
                    //3-Execution de la requette
                    SqlDataReader dr = command.ExecuteReader();
                    //4-Parcours de la requette
                    if (dr.Read())
                    {
                        //Mapping relationnel objet
                        consultation = new Consultation()
                        {

                            Id = (int)dr[0],
                            Date = dr[1].ToString(),
                            Constantes = dr[13].ToString(),
                            Patient = patientRepository.findById((int)dr[6]),



                            //Medecin=userrepo.findibyId( (int)dr[0])


                        };


                    }
                    dr.Close();

                }
                catch (Exception ex)
                {
                    throw ex;

                }
                finally
                {
                    command.Dispose();
                    //-5 Fermeture de la Connexion
                    connection.Close();

                }
            }
            return consultation;
        }

        public List<ConsultationDto> findByLibelle(string date)
        {
            List<ConsultationDto> consultations = new List<ConsultationDto>();
            //Ouvrir la connexion
            using (var connection = new SqlConnection(ConnexionString))
            using (var command = new SqlCommand())
            {
                try
                {
                    connection.Open();
                    command.Connection = connection;
                    //2-Prepare la requette
                    command.CommandText = SQL_SELECT_DATE;
                    //-Changer les parametres par leurs valeurs
                    command.Parameters.Add("@date", SqlDbType.Date).Value = date;
                    //3-Execution de la requette
                    SqlDataReader dr = command.ExecuteReader();
                    //4-Parcours de la requette
                    while (dr.Read())
                    {
                        int id = (int)dr[6];
                        //Mapping relationnel objet
                        ConsultationDto consultation = new ConsultationDto()
                        {
                            Id = (int)dr[0],
                            Date = dr[1].ToString(),
                           
                            
                            Patient = patientRepository.findById(id)

                        };
                        consultations.Add(consultation);
                    }
                    dr.Close();

                }
                catch (Exception ex)
                {
                    throw ex;

                }
                finally
                {
                    command.Dispose();
                    //-5 Fermeture de la Connexion
                    connection.Close();

                }
            }
            return consultations;
        }

        public List<ConsultationDto> findByLibellePatient(Patient patient)
        {
            List<ConsultationDto> consultations = new List<ConsultationDto>();
            //Ouvrir la connexion
            using (var connection = new SqlConnection(ConnexionString))
            using (var command = new SqlCommand())
            {
                try
                {
                    connection.Open();
                    command.Connection = connection;
                    //2-Prepare la requette
                    command.CommandText = SQL_SELECT_Patient;
                    //-Changer les parametres par leurs valeurs
                    command.Parameters.Add("@patient_id", SqlDbType.Int).Value = patient.Id;
                    //3-Execution de la requette
                    SqlDataReader dr = command.ExecuteReader();
                    //4-Parcours de la requette
                    while (dr.Read())
                    {
                        int id1 = (int)dr[6];
                        //Mapping relationnel objet
                        ConsultationDto consultation = new ConsultationDto()
                        {
                            Id = (int)dr[0],
                            
                            Date =dr[1].ToString(),
                           
                            
                            Patient = patientRepository.findById(id1)

                        };
                        consultations.Add(consultation);
                    }
                    dr.Close();

                }
                catch (Exception ex)
                {
                    throw ex;

                }
                finally
                {
                    command.Dispose();
                    //-5 Fermeture de la Connexion
                    connection.Close();

                }
            }
            return consultations;
        }

        public void save(Consultation consultation)
        {
            //Ouvrir la connexion
            using (var connection = new SqlConnection(ConnexionString))
            using (var command = new SqlCommand())
            {
                try
                {
                    connection.Open();
                    command.Connection = connection;
                    //2-Prepare la requette
                    command.CommandText = SQL_INSERT;

                    command.Parameters.Add("@constantes", SqlDbType.NVarChar).Value = consultation.Constantes;
                    command.Parameters.Add("@date", SqlDbType.Date).Value = consultation.Date;
                    //command.Parameters.Add("@temperature", SqlDbType.NVarChar).Value = consultation.Temperature;
                    //command.Parameters.Add("@tension", SqlDbType.NVarChar).Value = consultation.Tension;
                    //command.Parameters.Add("@poids", SqlDbType.NVarChar).Value = consultation.Poids;
                    command.Parameters.Add("@patient_id", SqlDbType.Int).Value = consultation.Patient.Id;
                    //command.Parameters.Add("@group_sanguin", SqlDbType.NVarChar).Value = consultation.GroupeSanguin;
                   // command.Parameters.Add("@dateNaissance", SqlDbType.DateTime).Value = consultation.DateNaissance;
                   // command.Parameters.Add("@tel", SqlDbType.NVarChar).Value = consultation.Telephone;
                   // command.Parameters.Add("@adresse", SqlDbType.NVarChar).Value = consultation.Adresse;




                    //3-Execution de la requette
                    command.ExecuteNonQuery();


                }
                catch (Exception ex)
                {
                    throw ex;

                }
                finally
                {
                    command.Dispose();
                    //-5 Fermeture de la Connexion
                    connection.Close();

                }
            }
        }
    }
}
