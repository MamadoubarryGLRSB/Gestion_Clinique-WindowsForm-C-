﻿using GestionClinique.dto;
using GestionClinique.models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ToolTip;

namespace GestionClinique.repository
{
    public interface IRendezVousRepository
    {
        List<RendezVous> findAll();
        List<RendezVous> findAllMedecin(User user, string date);
        List<RendezVous> findAllRp(User user, string date);  
        List<RendezVous> findByLibelle(string date);
        void save(RendezVous rendezVous);
        void update(RendezVous rendezVous);
        void persit(RendezVous rendezVous);
        RendezVous search(string date, string heure, User user);
        RendezVous searchRp(string date, string heure, User user);





    }
}
