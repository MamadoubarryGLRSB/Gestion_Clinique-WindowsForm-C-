﻿using GestionClinique.models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionClinique.repository
{
    public class CalendrierRepository :BaseRepository,ICalendrierRepository
    {
        private readonly string SQL_INSERT = @"insert into Planning(heure,jour,medecin_id) values(@heure,@jour,@medecin_id)";
        public CalendrierRepository(string connexionString)
        {
            ConnexionString = connexionString;
            

        }
        public void save(Calendrier calendrier)
        {
            //Ouvrir la connexion
            using (var connection = new SqlConnection(ConnexionString))
            using (var command = new SqlCommand())
            {
                try
                {
                    connection.Open();
                    command.Connection = connection;
                    //2-Prepare la requette
                    command.CommandText = SQL_INSERT;

                    command.Parameters.Add("@heure", SqlDbType.NVarChar).Value = calendrier.Heure;
                    command.Parameters.Add("@jour", SqlDbType.NVarChar).Value = calendrier.Jour;
                    command.Parameters.Add("@medecin_id", SqlDbType.Int).Value = calendrier.Medecin.Id;

                    //3-Execution de la requette
                    command.ExecuteNonQuery();


                }
                catch (Exception ex)
                {
                    throw ex;

                }
                finally
                {
                    command.Dispose();
                    //-5 Fermeture de la Connexion
                    connection.Close();

                }
            }
        }
    }
}
