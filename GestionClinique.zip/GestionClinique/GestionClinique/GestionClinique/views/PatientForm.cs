﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GestionClinique.views
{
    public partial class PatientForm : Form,IViewsPatient
    {
        public PatientForm()
        {
            InitializeComponent();
            activeEventPatien();
        }
        public event EventHandler ajouterPatient;
        public event EventHandler dossier;

        public void activeEventPatien()
        {
            //Mappe Ecouteur et Objet
            btnAdd.Click += delegate { ajouterPatient.Invoke(this, EventArgs.Empty); };
            btnDossier.Click += delegate { dossier.Invoke(this, EventArgs.Empty); };


            //dtgPatient.SelectionChanged += delegate { SelectonLigneDgvEvent.Invoke(this, EventArgs.Empty); };


        }

        public string saisieNom { 
            get => txtPrenom.Text; 
            set => txtPrenom.Text=value; }
        public string saisiePrenom { 
            get => txtNom.Text; 
            set =>txtPrenom.Text=value; }
        public string saisieAntecedent { 
            get => txtAntecedent.Text; 
            set => txtAntecedent.Text=value; }
        public string saisieSexe { 
            get => txtSexe.Text; 
            set => txtSexe.Text=value; }
        public string saisieDateNaissance { 
            get => txtNaissance.Text; 
            set => txtNaissance.Text=value; }
        public string saisieAdresse { 
            get => txtAdresse.Text; 
            set => txtAdresse.Text=value; }
        public string saisieTelephone { 
            get =>txtTelephone.Text;
            set => txtTelephone.Text = value; }

        public void setClasseBindingSource(BindingSource classeListPatient)
        {
            dtgPatient.DataSource = classeListPatient;
            dtgPatient.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }
        
        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void dtgPatient_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        //Design Pattern => Singleton

        private static PatientForm instance = null;

        public static PatientForm showForm(Form parent)
        {
            if (parent.ActiveMdiChild != null)
            {
                parent.ActiveMdiChild.Hide();
                instance = null;
            }
            if (instance == null || instance.IsDisposed)
            {
                instance = new PatientForm();
                instance.MdiParent = parent;
            }
            return instance;
        }

        public void CacherBtn()
        {
            btnAdd.Visible = false;
        }

        private void txtSexe_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtNaissance_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
