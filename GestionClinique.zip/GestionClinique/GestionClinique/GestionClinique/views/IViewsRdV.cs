﻿using GestionClinique.models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Gestion_Clinique.views
{
    public interface IViewsRdV
    {
        //Proprietes
        DateTime libelleRechercheDate { get; set; }
        DateTime saisieDate { get; set; }
        string saisieHeure { get; set; }
        string type { get; set; }
        Patient Patient { get; set; }
        User User { get; set; }
        void Cacherrv();
        void CacherBtn();
        //event
        event EventHandler plannifierRdV;
        event EventHandler annulerRdv;
        event EventHandler ValiderRdv;
        event EventHandler rechercherDate;
        event EventHandler modifier;



        //Methodes
        void setRendezVousBindingSource(BindingSource rendezVousList,BindingSource typeList, BindingSource patientList, BindingSource medecinList);
        void Show();
        void hide();
    }
}
