﻿namespace GestionClinique.views
{
    partial class menuForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblUserConnect = new System.Windows.Forms.Label();
            this.btnPatient = new System.Windows.Forms.Button();
            this.btnPrestation = new System.Windows.Forms.Button();
            this.btnConsultation = new System.Windows.Forms.Button();
            this.btnRdV = new System.Windows.Forms.Button();
            this.btnDeconnecte = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.lblUserConnect);
            this.panel1.Controls.Add(this.btnDeconnecte);
            this.panel1.Controls.Add(this.btnPatient);
            this.panel1.Controls.Add(this.btnPrestation);
            this.panel1.Controls.Add(this.btnConsultation);
            this.panel1.Controls.Add(this.btnRdV);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(251, 772);
            this.panel1.TabIndex = 0;
            // 
            // lblUserConnect
            // 
            this.lblUserConnect.AutoSize = true;
            this.lblUserConnect.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblUserConnect.Location = new System.Drawing.Point(69, 19);
            this.lblUserConnect.Name = "lblUserConnect";
            this.lblUserConnect.Size = new System.Drawing.Size(85, 29);
            this.lblUserConnect.TabIndex = 5;
            this.lblUserConnect.Text = "label1";
            // 
            // btnPatient
            // 
            this.btnPatient.BackColor = System.Drawing.Color.White;
            this.btnPatient.Location = new System.Drawing.Point(0, 241);
            this.btnPatient.Name = "btnPatient";
            this.btnPatient.Size = new System.Drawing.Size(254, 39);
            this.btnPatient.TabIndex = 3;
            this.btnPatient.Text = "Patient";
            this.btnPatient.UseVisualStyleBackColor = false;
            this.btnPatient.Click += new System.EventHandler(this.btnPatient_Click);
            // 
            // btnPrestation
            // 
            this.btnPrestation.BackColor = System.Drawing.Color.White;
            this.btnPrestation.Location = new System.Drawing.Point(0, 181);
            this.btnPrestation.Name = "btnPrestation";
            this.btnPrestation.Size = new System.Drawing.Size(254, 45);
            this.btnPrestation.TabIndex = 2;
            this.btnPrestation.Text = "Prestation";
            this.btnPrestation.UseVisualStyleBackColor = false;
            // 
            // btnConsultation
            // 
            this.btnConsultation.BackColor = System.Drawing.Color.White;
            this.btnConsultation.Location = new System.Drawing.Point(-3, 120);
            this.btnConsultation.Name = "btnConsultation";
            this.btnConsultation.Size = new System.Drawing.Size(254, 46);
            this.btnConsultation.TabIndex = 1;
            this.btnConsultation.Text = "Consultation";
            this.btnConsultation.UseVisualStyleBackColor = false;
            // 
            // btnRdV
            // 
            this.btnRdV.BackColor = System.Drawing.Color.White;
            this.btnRdV.Location = new System.Drawing.Point(0, 60);
            this.btnRdV.Name = "btnRdV";
            this.btnRdV.Size = new System.Drawing.Size(251, 44);
            this.btnRdV.TabIndex = 0;
            this.btnRdV.Text = "Rendez-Vous";
            this.btnRdV.UseVisualStyleBackColor = false;
            this.btnRdV.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnDeconnecte
            // 
            this.btnDeconnecte.BackColor = System.Drawing.Color.Red;
            this.btnDeconnecte.BackgroundImage = global::GestionClinique.Properties.Resources.logout_icon_glassy_brown_round_b;
            this.btnDeconnecte.Location = new System.Drawing.Point(-3, 703);
            this.btnDeconnecte.Name = "btnDeconnecte";
            this.btnDeconnecte.Size = new System.Drawing.Size(84, 84);
            this.btnDeconnecte.TabIndex = 4;
            this.btnDeconnecte.UseVisualStyleBackColor = false;
            // 
            // menuForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(1699, 772);
            this.Controls.Add(this.panel1);
            this.IsMdiContainer = true;
            this.Name = "menuForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MenuForm";
            this.Load += new System.EventHandler(this.MenuForm_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnPrestation;
        private System.Windows.Forms.Button btnConsultation;
        private System.Windows.Forms.Button btnRdV;
        private System.Windows.Forms.Button btnPatient;
        private System.Windows.Forms.Button btnDeconnecte;
        private System.Windows.Forms.Label lblUserConnect;
    }
}