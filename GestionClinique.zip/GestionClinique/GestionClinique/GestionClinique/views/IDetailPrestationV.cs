﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionClinique.views
{
    public interface IDetailPrestationV
    {
        string date { get; set; }

        string nompatient { get; set; }
        string prenompatient { get; set; }
        string constantes { get; set; }



        void Show();


        void Hide();
    }
}
