﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GestionClinique.views
{
    public partial class ConsultForm : Form,IconsultV
    {
        public ConsultForm()
        {
            InitializeComponent();
            btnP.Click += delegate { enregistrerPrestation.Invoke(this, EventArgs.Empty); };
            btnC.Click += delegate { enregistrer.Invoke(this, EventArgs.Empty); };
        }

       
        public bool prestation { 
            get =>groupPrestation.Enabled; 
            set => groupPrestation.Enabled=value; }
        public bool consultation { 
            get => groupConsulte.Enabled; 
            set => groupConsulte.Enabled=value; }
        public string dateC { 
            get => throw new NotImplementedException(); 
            set => lbDateC.Text=value; }
        public string prenomC { 
            get => throw new NotImplementedException(); 
            set => lbprenomC.Text=value; }
        public string dateP { 
            get => throw new NotImplementedException();
            set => LbDatePrestation.Text=value; }
        public string nomC { 
            get => throw new NotImplementedException(); 
            set => lbnomC.Text=value; }
       
        public string constantesC { 
            get => txtConstanteC.Text; 
            set => txtConstanteC.Text=value; }
        public string constantesP { 
            get => txtPrestationP.Text; 
            set => txtPrestationP.Text=value; }
        public string prenomP { 
            get => throw new NotImplementedException(); 
            set => lbPrenomPrestation.Text=value; }
        public string nomP { 
            get => throw new NotImplementedException(); 
            set =>lbNomPrestation.Text=value; }

        public event EventHandler enregistrerPrestation;
        public event EventHandler enregistrer;

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void ConsultForm_Load(object sender, EventArgs e)
        {

        }
    }
}
