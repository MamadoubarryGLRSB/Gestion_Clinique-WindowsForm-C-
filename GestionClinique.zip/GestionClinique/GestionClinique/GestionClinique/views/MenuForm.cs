﻿using GestionClinique.models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GestionClinique.views
{
    public partial class menuForm : Form, IViewMenu
    {
       
        public menuForm()
        {
            InitializeComponent();
            activeEventClasse();
          
        }

        public event EventHandler showRdV;
        public event EventHandler showConsultation;
        public event EventHandler showPatient;
        public event EventHandler showPrestation;
        public event EventHandler showDossier;
        public event EventHandler showDeconnection;

        private void MenuForm_Load(object sender, EventArgs e)
        {

        }
        public void activeEventClasse()
        {
            //Mappe Ecouteur et Objet
            btnRdV.Click += delegate { showRdV.Invoke(this, EventArgs.Empty); };
            btnConsultation.Click += delegate { showConsultation.Invoke(this, EventArgs.Empty); };
            btnPatient.Click += delegate { showPatient.Invoke(this, EventArgs.Empty); };
            btnPrestation.Click += delegate { showPrestation.Invoke(this, EventArgs.Empty); };
            btnDeconnecte.Click += delegate { showDeconnection.Invoke(this, EventArgs.Empty); };
        }


        public bool consultation
        {
            get => btnConsultation.Visible;
            set => btnConsultation.Visible =value;
        }
        public bool prestation
        {
            get => btnPrestation.Visible;
            set => btnPrestation.Visible = value;
        }
        public bool patient
        {
            get => btnPatient.Visible;
            set => btnPatient.Visible = value;
        }
        public bool rdv
        {
            get => btnRdV.Visible; 
            set => btnRdV.Visible = value;
        }
        public User userConnect { 
            get ; set ; }
        public string userLabel { 
            get => lblUserConnect.Text; 
            set => lblUserConnect.Text=value; }
       

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void btnPatient_Click(object sender, EventArgs e)
        {

        }
    }
}
