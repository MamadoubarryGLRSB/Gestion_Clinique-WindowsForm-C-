﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GestionClinique.views
{
    public interface IDetailConsultationViews
    {
        //proprietes
        string date { get; set; }
        
        string nompatient { get; set; }
        string prenompatient { get; set; }
        string constantes { get; set; }
        


        void Show();
        

        void Hide();
    }
}
