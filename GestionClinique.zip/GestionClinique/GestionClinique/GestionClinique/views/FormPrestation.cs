﻿using GestionClinique.dto;
using GestionClinique.models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GestionClinique.views
{
    public partial class FormPrestation : Form,IViewsPrestation
    {
        
        public FormPrestation()
        {
            InitializeComponent();
            activeEventPatien();
        }
        public void activeEventPatien()
        {
            //Mappe Ecouteur et Objet
          
            btnOk1.Click += delegate { rechercherPatient.Invoke(this, EventArgs.Empty); };
            btnOk2.Click += delegate { rechercherDate.Invoke(this, EventArgs.Empty); };
            btnDetail.Click += delegate { voirDetail.Invoke(this, EventArgs.Empty); };

        }

        public event EventHandler ajouterPrestation;
        public event EventHandler rechercherPatient;
        public event EventHandler rechercherDate;
        public event EventHandler voirDetail;

        public PatientDto libelleRechechePatient {
            get => cboxPatient.SelectedItem as PatientDto;
            set => throw new NotImplementedException();
        }
        public DateTime libelleRechercheDate {
            get => cbDateC1.Value; 
            set => throw new NotImplementedException(); }
       
        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void dgvPrestation_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        public void setPrestationBindingSource(BindingSource prestationList, BindingSource patientList)
        {
             dgvPrestation.DataSource = prestationList;
             cboxPatient.DataSource = patientList;
             
             dgvPrestation.AutoSizeColumnsMode=DataGridViewAutoSizeColumnsMode.Fill;
        }
        private static FormPrestation  instance = null;

        public static FormPrestation showForm(Form parent)
        {
            if (parent.ActiveMdiChild != null)
            {
                parent.ActiveMdiChild.Hide();
                instance = null;
            }
            if (instance == null || instance.IsDisposed)
            {
                instance = new FormPrestation();
                instance.MdiParent = parent;
            }
            return instance;
        }

        public void hide()
        {
            throw new NotImplementedException();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {

        }

        public void btnCacheP()
        {
            btnDetail.Visible=false;
        }
    }
}
