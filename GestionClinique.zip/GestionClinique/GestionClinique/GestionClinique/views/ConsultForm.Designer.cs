﻿namespace GestionClinique.views
{
    partial class ConsultForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupConsulte = new System.Windows.Forms.GroupBox();
            this.lbnomC = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnC = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txtConstanteC = new System.Windows.Forms.TextBox();
            this.lbprenomC = new System.Windows.Forms.Label();
            this.labelP = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lbDateC = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupPrestation = new System.Windows.Forms.GroupBox();
            this.lbNomPrestation = new System.Windows.Forms.Label();
            this.lbPrenomPrestation = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btnP = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.txtPrestationP = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.LbDatePrestation = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.groupConsulte.SuspendLayout();
            this.groupPrestation.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupConsulte
            // 
            this.groupConsulte.Controls.Add(this.lbnomC);
            this.groupConsulte.Controls.Add(this.label3);
            this.groupConsulte.Controls.Add(this.btnC);
            this.groupConsulte.Controls.Add(this.label9);
            this.groupConsulte.Controls.Add(this.label7);
            this.groupConsulte.Controls.Add(this.txtConstanteC);
            this.groupConsulte.Controls.Add(this.lbprenomC);
            this.groupConsulte.Controls.Add(this.labelP);
            this.groupConsulte.Controls.Add(this.label4);
            this.groupConsulte.Controls.Add(this.lbDateC);
            this.groupConsulte.Controls.Add(this.label1);
            this.groupConsulte.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupConsulte.Location = new System.Drawing.Point(46, 35);
            this.groupConsulte.Name = "groupConsulte";
            this.groupConsulte.Size = new System.Drawing.Size(538, 624);
            this.groupConsulte.TabIndex = 0;
            this.groupConsulte.TabStop = false;
            this.groupConsulte.Text = "Consultation";
            this.groupConsulte.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // lbnomC
            // 
            this.lbnomC.AutoSize = true;
            this.lbnomC.Location = new System.Drawing.Point(136, 139);
            this.lbnomC.Name = "lbnomC";
            this.lbnomC.Size = new System.Drawing.Size(79, 29);
            this.lbnomC.TabIndex = 13;
            this.lbnomC.Text = "label5";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(35, 139);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 29);
            this.label3.TabIndex = 12;
            this.label3.Text = "Nom";
            // 
            // btnC
            // 
            this.btnC.BackColor = System.Drawing.Color.LimeGreen;
            this.btnC.Location = new System.Drawing.Point(163, 531);
            this.btnC.Name = "btnC";
            this.btnC.Size = new System.Drawing.Size(147, 41);
            this.btnC.TabIndex = 11;
            this.btnC.Text = "Enregistrer";
            this.btnC.UseVisualStyleBackColor = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(42, 243);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(133, 29);
            this.label9.TabIndex = 10;
            this.label9.Text = "Constantes";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(58, 272);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(0, 29);
            this.label7.TabIndex = 7;
            // 
            // txtConstanteC
            // 
            this.txtConstanteC.Location = new System.Drawing.Point(47, 289);
            this.txtConstanteC.Multiline = true;
            this.txtConstanteC.Name = "txtConstanteC";
            this.txtConstanteC.Size = new System.Drawing.Size(413, 180);
            this.txtConstanteC.TabIndex = 6;
            // 
            // lbprenomC
            // 
            this.lbprenomC.AutoSize = true;
            this.lbprenomC.Location = new System.Drawing.Point(136, 190);
            this.lbprenomC.Name = "lbprenomC";
            this.lbprenomC.Size = new System.Drawing.Size(79, 29);
            this.lbprenomC.TabIndex = 5;
            this.lbprenomC.Text = "label5";
            // 
            // labelP
            // 
            this.labelP.AutoSize = true;
            this.labelP.Location = new System.Drawing.Point(35, 190);
            this.labelP.Name = "labelP";
            this.labelP.Size = new System.Drawing.Size(98, 29);
            this.labelP.TabIndex = 4;
            this.labelP.Text = "Prenom";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(35, 127);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 29);
            this.label4.TabIndex = 2;
            // 
            // lbDateC
            // 
            this.lbDateC.AutoSize = true;
            this.lbDateC.Location = new System.Drawing.Point(136, 66);
            this.lbDateC.Name = "lbDateC";
            this.lbDateC.Size = new System.Drawing.Size(79, 29);
            this.lbDateC.TabIndex = 1;
            this.lbDateC.Text = "label2";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(35, 66);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 29);
            this.label1.TabIndex = 0;
            this.label1.Text = "Date";
            // 
            // groupPrestation
            // 
            this.groupPrestation.Controls.Add(this.lbNomPrestation);
            this.groupPrestation.Controls.Add(this.lbPrenomPrestation);
            this.groupPrestation.Controls.Add(this.label2);
            this.groupPrestation.Controls.Add(this.label5);
            this.groupPrestation.Controls.Add(this.btnP);
            this.groupPrestation.Controls.Add(this.label10);
            this.groupPrestation.Controls.Add(this.label13);
            this.groupPrestation.Controls.Add(this.txtPrestationP);
            this.groupPrestation.Controls.Add(this.label16);
            this.groupPrestation.Controls.Add(this.LbDatePrestation);
            this.groupPrestation.Controls.Add(this.label18);
            this.groupPrestation.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupPrestation.Location = new System.Drawing.Point(701, 35);
            this.groupPrestation.Name = "groupPrestation";
            this.groupPrestation.Size = new System.Drawing.Size(538, 624);
            this.groupPrestation.TabIndex = 12;
            this.groupPrestation.TabStop = false;
            this.groupPrestation.Text = "Prestation";
            this.groupPrestation.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // lbNomPrestation
            // 
            this.lbNomPrestation.AutoSize = true;
            this.lbNomPrestation.Location = new System.Drawing.Point(158, 127);
            this.lbNomPrestation.Name = "lbNomPrestation";
            this.lbNomPrestation.Size = new System.Drawing.Size(92, 29);
            this.lbNomPrestation.TabIndex = 17;
            this.lbNomPrestation.Text = "label17";
            // 
            // lbPrenomPrestation
            // 
            this.lbPrenomPrestation.AutoSize = true;
            this.lbPrenomPrestation.Location = new System.Drawing.Point(158, 190);
            this.lbPrenomPrestation.Name = "lbPrenomPrestation";
            this.lbPrenomPrestation.Size = new System.Drawing.Size(92, 29);
            this.lbPrenomPrestation.TabIndex = 16;
            this.lbPrenomPrestation.Text = "label17";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(33, 127);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 29);
            this.label2.TabIndex = 15;
            this.label2.Text = "Nom";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(33, 190);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(98, 29);
            this.label5.TabIndex = 14;
            this.label5.Text = "Prenom";
            // 
            // btnP
            // 
            this.btnP.BackColor = System.Drawing.Color.LimeGreen;
            this.btnP.Location = new System.Drawing.Point(163, 531);
            this.btnP.Name = "btnP";
            this.btnP.Size = new System.Drawing.Size(147, 41);
            this.btnP.TabIndex = 11;
            this.btnP.Text = "Enregistrer";
            this.btnP.UseVisualStyleBackColor = false;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(42, 243);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(133, 29);
            this.label10.TabIndex = 10;
            this.label10.Text = "Constantes";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(58, 272);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(0, 29);
            this.label13.TabIndex = 7;
            // 
            // txtPrestationP
            // 
            this.txtPrestationP.Location = new System.Drawing.Point(47, 289);
            this.txtPrestationP.Multiline = true;
            this.txtPrestationP.Name = "txtPrestationP";
            this.txtPrestationP.Size = new System.Drawing.Size(408, 180);
            this.txtPrestationP.TabIndex = 6;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(35, 127);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(0, 29);
            this.label16.TabIndex = 2;
            // 
            // LbDatePrestation
            // 
            this.LbDatePrestation.AutoSize = true;
            this.LbDatePrestation.Location = new System.Drawing.Point(158, 66);
            this.LbDatePrestation.Name = "LbDatePrestation";
            this.LbDatePrestation.Size = new System.Drawing.Size(92, 29);
            this.LbDatePrestation.TabIndex = 1;
            this.LbDatePrestation.Text = "label17";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(35, 66);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(63, 29);
            this.label18.TabIndex = 0;
            this.label18.Text = "Date";
            // 
            // ConsultForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1380, 690);
            this.Controls.Add(this.groupPrestation);
            this.Controls.Add(this.groupConsulte);
            this.Name = "ConsultForm";
            this.Text = "ConsultForm";
            this.Load += new System.EventHandler(this.ConsultForm_Load);
            this.groupConsulte.ResumeLayout(false);
            this.groupConsulte.PerformLayout();
            this.groupPrestation.ResumeLayout(false);
            this.groupPrestation.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupConsulte;
        private System.Windows.Forms.Label lbDateC;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnC;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtConstanteC;
        private System.Windows.Forms.Label lbprenomC;
        private System.Windows.Forms.Label labelP;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupPrestation;
        private System.Windows.Forms.Button btnP;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtPrestationP;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label LbDatePrestation;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label lbnomC;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lbNomPrestation;
        private System.Windows.Forms.Label lbPrenomPrestation;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label5;
    }
}