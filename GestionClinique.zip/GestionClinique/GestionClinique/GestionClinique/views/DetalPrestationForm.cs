﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GestionClinique.views
{
    public partial class DetalPrestationForm : Form,IDetailPrestationViews
    {
        public DetalPrestationForm()
        {
            InitializeComponent();
        }

        public string date
        {
            get => throw new NotImplementedException();
            set => lbDate.Text = value;
        }

        public string nompatient
        {
            get => throw new NotImplementedException();
            set => lbNom.Text = value;
        }
        public string prenompatient
        {
            get => throw new NotImplementedException();
            set => lbPrenom.Text = value;
        }
        public string constantes
        {
            get => lbConstantes.Text.Trim();
            set => lbConstantes.Text = value;
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}
