﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionClinique.views
{
    public interface IconsultV
    {
        string dateC { get; set; }
       
        string prenomC { get; set;}
        string dateP { get; set; }
        string nomC { get; set; }
        string prenomP { get; set; }
        string nomP { get; set; }
        string constantesC { get; set; }
        string constantesP { get; set;}
        bool prestation { get; set; }
        bool consultation { get; set; }

        event EventHandler enregistrerPrestation;
        event EventHandler enregistrer;

        void Show();
        void Hide();
    }
}
