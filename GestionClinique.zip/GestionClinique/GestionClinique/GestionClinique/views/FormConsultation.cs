﻿using GestionClinique.dto;
using GestionClinique.models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GestionClinique.views
{
    public partial class FormConsultation : Form,IViewsConsultation
    {
        public FormConsultation()
        {
            InitializeComponent();
            activeEventPatien();
        }

        public void setConsultationBindingSource(BindingSource consultationList, BindingSource patientList)
        {
            dgvConsultation.DataSource = consultationList;
            
            cbPatient.DataSource = patientList;

            dgvConsultation.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        public event EventHandler ajouterConsultation;
        public event EventHandler rechercherPatient;
        public event EventHandler rechercherDate;
        public event EventHandler voirDetail;
        public event EventHandler ordonnance;

        public void activeEventPatien()
        {
            //Mappe Ecouteur et Objet
            
            btnOk1.Click += delegate { rechercherPatient.Invoke(this, EventArgs.Empty); };
            btnOk2.Click += delegate { rechercherDate.Invoke(this, EventArgs.Empty); };
            btnDetail.Click += delegate { voirDetail.Invoke(this, EventArgs.Empty); };
           

        }

        private void dgvConsultation_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        private static FormConsultation instance = null;

     


        
        public PatientDto libelleRechechePatient { 
            get => cbPatient.SelectedItem as PatientDto; 
            set => throw new NotImplementedException(); }
        public DateTime libelleRechercheDate {
            get => cbDateC1.Value;
            set => throw new NotImplementedException(); }
       
        
        public static FormConsultation showForm(Form parent)
        {
            if (parent.ActiveMdiChild != null)
            {
                parent.ActiveMdiChild.Hide();
                instance = null;
            }
            if (instance == null || instance.IsDisposed)
            {
                instance = new FormConsultation();
                instance.MdiParent = parent;
            }
            return instance;
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void FormConsultation_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        public void hide()
        {
            throw new NotImplementedException();
        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void txtPoids_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        public void cacheBtnC()
        {
            btnDetail.Visible=false;
        }
    }
}
