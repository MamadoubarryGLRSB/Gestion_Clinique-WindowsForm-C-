﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GestionClinique.views
{
    public interface IDossierMedicalVews
    {
        string type { get; set; }
        string nom { get; set; }
        string prenom { get; set; }
        string code { get; set; }
        string antecedent { get; set; }
        string sexe { get; set; }
        string naissance { get; set; }
        string adresse { get; set; }
        string telephone { get; set; }

        event EventHandler ok;
        void setDossierBindingSource(BindingSource dossierList, BindingSource typeList);
        void Hide();
        void Show();
    }
}
