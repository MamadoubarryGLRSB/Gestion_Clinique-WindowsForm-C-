﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GestionClinique.views
{
    public interface IViewsPatient
    {
        string saisieNom { get; set; }
        string saisiePrenom { get; set; }
        string saisieAntecedent { get; set; }
        string saisieSexe{ get; set; }
        string saisieDateNaissance { get; set; }
        string saisieAdresse { get; set; }
        string saisieTelephone { get; set; }

        //Events
        event EventHandler ajouterPatient;
        event EventHandler dossier;
        void CacherBtn();
        


        void setClasseBindingSource(BindingSource classeListPatient);

        void Show();


        void Hide();

    }
}
