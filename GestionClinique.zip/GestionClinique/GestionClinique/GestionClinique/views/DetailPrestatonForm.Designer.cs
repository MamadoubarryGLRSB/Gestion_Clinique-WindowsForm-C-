﻿namespace GestionClinique.views
{
    partial class DetailPrestatonForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lConstante = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.lPrenom = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.lNom = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lDate = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.groupBox1.Controls.Add(this.lConstante);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.lPrenom);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.lNom);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.lDate);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(56, 28);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(620, 636);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Detail";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // lConstante
            // 
            this.lConstante.AutoSize = true;
            this.lConstante.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lConstante.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lConstante.Location = new System.Drawing.Point(249, 232);
            this.lConstante.Name = "lConstante";
            this.lConstante.Size = new System.Drawing.Size(79, 29);
            this.lConstante.TabIndex = 23;
            this.lConstante.Text = "label2";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(34, 232);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(133, 29);
            this.label11.TabIndex = 22;
            this.label11.Text = "Constantes";
            // 
            // lPrenom
            // 
            this.lPrenom.AutoSize = true;
            this.lPrenom.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lPrenom.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lPrenom.Location = new System.Drawing.Point(249, 176);
            this.lPrenom.Name = "lPrenom";
            this.lPrenom.Size = new System.Drawing.Size(79, 29);
            this.lPrenom.TabIndex = 21;
            this.lPrenom.Text = "label2";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(34, 173);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(98, 29);
            this.label8.TabIndex = 20;
            this.label8.Text = "Prenom";
            // 
            // lNom
            // 
            this.lNom.AutoSize = true;
            this.lNom.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lNom.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lNom.Location = new System.Drawing.Point(249, 111);
            this.lNom.Name = "lNom";
            this.lNom.Size = new System.Drawing.Size(79, 29);
            this.lNom.TabIndex = 19;
            this.lNom.Text = "label2";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(34, 111);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(65, 29);
            this.label5.TabIndex = 18;
            this.label5.Text = "Nom";
            // 
            // lDate
            // 
            this.lDate.AutoSize = true;
            this.lDate.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lDate.Location = new System.Drawing.Point(249, 50);
            this.lDate.Name = "lDate";
            this.lDate.Size = new System.Drawing.Size(79, 29);
            this.lDate.TabIndex = 17;
            this.lDate.Text = "label2";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(34, 50);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 29);
            this.label2.TabIndex = 16;
            this.label2.Text = "Date";
            // 
            // DetailPrestatonForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1022, 667);
            this.Controls.Add(this.groupBox1);
            this.Name = "DetailPrestatonForm";
            this.Text = "DetailPrestatonForm";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lConstante;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label lPrenom;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lNom;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lDate;
        private System.Windows.Forms.Label label2;
    }
}