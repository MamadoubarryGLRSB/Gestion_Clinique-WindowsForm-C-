﻿using GestionClinique.dto;
using GestionClinique.models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GestionClinique.views
{
    public interface IViewsPrestation
    {
        PatientDto libelleRechechePatient { get; set; }
        DateTime libelleRechercheDate { get; set; }
        void btnCacheP();

        event EventHandler ajouterPrestation;
        event EventHandler rechercherPatient;
        event EventHandler rechercherDate;
        event EventHandler voirDetail;
        void setPrestationBindingSource(BindingSource prestationList, BindingSource patientList);
        void Show();
        void hide();
    }
}
