﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GestionClinique.views
{
    public partial class DetailConsultationForm : Form,IDetailConsultationViews
    {
        public string date { 
            get => throw new NotImplementedException(); 
            set =>lDate.Text=value; }
        
        public string nompatient { 
            get => throw new NotImplementedException(); 
            set => lNom.Text=value; }
        public string prenompatient { get => throw new NotImplementedException(); 
            set => lPrenom.Text=value; }
        public string constantes {
            get => lConstante.Text.Trim();
            set => lConstante.Text=value; }

        public DetailConsultationForm()
        {
            InitializeComponent();
        }

       
        private void dtgDetail_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void DetailConsultationForm_Load(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }
    }
}
