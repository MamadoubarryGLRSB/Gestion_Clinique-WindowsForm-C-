﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GestionClinique.views
{
    public partial class DossierMedicalForm : Form,IDossierMedicalVews
    {
        public DossierMedicalForm()
        {
            InitializeComponent();
            activeEventPatien();
            
        }

        public string type { 
            get => cboxType.Text; 
            set => cboxType.Text=value; }
        public string nom { 
            get => lbNom.Text; 
            set => lbNom.Text=value; }
        public string prenom { 
            get =>lbPrenom.Text; 
            set => lbPrenom.Text=value; }
        public string code { 
            get => lbCode.Text; 
            set => lbCode.Text=value; }
        public string antecedent { 
            get => lbAntecedent.Text; 
            set => lbAntecedent.Text=value; }
        public string sexe {
            get => lbSexe.Text;
            set => lbSexe.Text=value; }
        public string naissance { 
            get => lbDateNaissance.Text; 
            set => lbDateNaissance.Text=value; }
        public string adresse { 
            get => lbAdresse.Text; 
            set => lbAdresse.Text=value; }
        public string telephone { 
            get => lbTelephone.Text; 
            set => lbTelephone.Text=value; }

        public void setDossierBindingSource(BindingSource dossierList, BindingSource typeList)
        {
            dtgDossier.DataSource = dossierList;
            cboxType.DataSource = typeList;
            dtgDossier.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }


        private void dtgDossier_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        public void activeEventPatien()
        {
            //Mappe Ecouteur et Objet

            btnOk.Click += delegate { ok.Invoke(this, EventArgs.Empty); };
            
        }
       
        public event EventHandler ok;

       
        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}
