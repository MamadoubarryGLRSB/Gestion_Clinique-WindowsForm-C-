﻿using Gestion_Clinique.views;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Window;

namespace GestionClinique.views
{
    public partial class ConnexionView : Form,IViewsConnexion
    {
        public string Login {
            get => txtLogin.Text.Trim();
            set => txtLogin.Text = value;
        }
        public string Password {
            get => txtPassword.Text.Trim();
            set => txtPassword.Text = value;
        }
        public string Message { 
            get ; 
            set; }
        public bool isLogin { 
            get ; 
            set ; }

        public void activeEventClasse()
        {
            //Mappe Ecouteur et Objet
            btnConnexion.Click += delegate { seConnecter.Invoke(this, EventArgs.Empty);
            if(!isLogin)
                {
                    MessageBox.Show(Message);
                }
            
            };

        }
        public event EventHandler seConnecter;

        public ConnexionView()
        {
            InitializeComponent();
            this.activeEventClasse();
        }

      

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void Application_Load(object sender, EventArgs e)
        {

        }

        private void btnConnexion_Click(object sender, EventArgs e)
        {

        }
    }
}
