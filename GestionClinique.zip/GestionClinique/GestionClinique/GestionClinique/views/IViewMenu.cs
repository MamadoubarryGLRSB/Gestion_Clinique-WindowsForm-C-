﻿using GestionClinique.models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionClinique.views
{
    public interface IViewMenu
    {
        void Show();
        bool consultation { get; set; }
        bool prestation { get; set; }
        bool patient { get; set; }
        bool rdv { get; set; }
      

        string userLabel { get; set; }
        
        User userConnect { get; set; }
        void Close();

        //Events
        event EventHandler showRdV;
        event EventHandler showPatient;
        event EventHandler showConsultation;
        event EventHandler showPrestation;
        event EventHandler showDeconnection;

    }
}
