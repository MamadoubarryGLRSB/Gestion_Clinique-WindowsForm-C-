﻿namespace GestionClinique.views
{
    partial class FormPrestation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnDetail = new System.Windows.Forms.Button();
            this.dgvPrestation = new System.Windows.Forms.DataGridView();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnOk2 = new System.Windows.Forms.Button();
            this.cbDateC1 = new System.Windows.Forms.DateTimePicker();
            this.btnOk1 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.cboxPatient = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPrestation)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.groupBox1.Controls.Add(this.btnDetail);
            this.groupBox1.Controls.Add(this.dgvPrestation);
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.groupBox1.Location = new System.Drawing.Point(22, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1291, 728);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Liste des Prestations";
            // 
            // btnDetail
            // 
            this.btnDetail.BackColor = System.Drawing.Color.Lime;
            this.btnDetail.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDetail.ForeColor = System.Drawing.Color.Black;
            this.btnDetail.Location = new System.Drawing.Point(823, 67);
            this.btnDetail.Name = "btnDetail";
            this.btnDetail.Size = new System.Drawing.Size(169, 60);
            this.btnDetail.TabIndex = 37;
            this.btnDetail.Text = "Detail";
            this.btnDetail.UseVisualStyleBackColor = false;
            // 
            // dgvPrestation
            // 
            this.dgvPrestation.BackgroundColor = System.Drawing.SystemColors.ActiveCaption;
            this.dgvPrestation.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvPrestation.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPrestation.Location = new System.Drawing.Point(6, 150);
            this.dgvPrestation.Name = "dgvPrestation";
            this.dgvPrestation.RowHeadersWidth = 51;
            this.dgvPrestation.RowTemplate.Height = 24;
            this.dgvPrestation.Size = new System.Drawing.Size(1025, 511);
            this.dgvPrestation.TabIndex = 33;
            this.dgvPrestation.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvPrestation_CellContentClick);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.WhiteSmoke;
            this.groupBox2.Controls.Add(this.btnOk2);
            this.groupBox2.Controls.Add(this.cbDateC1);
            this.groupBox2.Controls.Add(this.btnOk1);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.cboxPatient);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(6, 55);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(779, 80);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Filtre";
            // 
            // btnOk2
            // 
            this.btnOk2.BackColor = System.Drawing.Color.Honeydew;
            this.btnOk2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOk2.ForeColor = System.Drawing.Color.Black;
            this.btnOk2.Location = new System.Drawing.Point(679, 29);
            this.btnOk2.Name = "btnOk2";
            this.btnOk2.Size = new System.Drawing.Size(64, 33);
            this.btnOk2.TabIndex = 26;
            this.btnOk2.Text = "Ok";
            this.btnOk2.UseVisualStyleBackColor = false;
            // 
            // cbDateC1
            // 
            this.cbDateC1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.cbDateC1.Location = new System.Drawing.Point(479, 35);
            this.cbDateC1.Name = "cbDateC1";
            this.cbDateC1.Size = new System.Drawing.Size(163, 27);
            this.cbDateC1.TabIndex = 25;
            // 
            // btnOk1
            // 
            this.btnOk1.BackColor = System.Drawing.Color.Honeydew;
            this.btnOk1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOk1.ForeColor = System.Drawing.Color.Black;
            this.btnOk1.Location = new System.Drawing.Point(310, 29);
            this.btnOk1.Name = "btnOk1";
            this.btnOk1.Size = new System.Drawing.Size(67, 34);
            this.btnOk1.TabIndex = 5;
            this.btnOk1.Text = "Ok";
            this.btnOk1.UseVisualStyleBackColor = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(400, 34);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(64, 29);
            this.label2.TabIndex = 24;
            this.label2.Text = "date";
            // 
            // cboxPatient
            // 
            this.cboxPatient.FormattingEnabled = true;
            this.cboxPatient.Location = new System.Drawing.Point(119, 32);
            this.cboxPatient.Name = "cboxPatient";
            this.cboxPatient.Size = new System.Drawing.Size(164, 28);
            this.cboxPatient.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(23, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(79, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Patient";
            // 
            // FormPrestation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.ClientSize = new System.Drawing.Size(1371, 779);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FormPrestation";
            this.Text = "FormPrestation";
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvPrestation)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cboxPatient;
        private System.Windows.Forms.Button btnOk1;
        private System.Windows.Forms.DateTimePicker cbDateC1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnOk2;
        private System.Windows.Forms.DataGridView dgvPrestation;
        private System.Windows.Forms.Button btnDetail;
    }
}