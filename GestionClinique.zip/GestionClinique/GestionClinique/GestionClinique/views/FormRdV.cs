﻿using Gestion_Clinique.views;
using GestionClinique.models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GestionClinique.views
{
    public partial class FormRdV : Form,IViewsRdV
    {
        public FormRdV()
        {
            InitializeComponent();
            activeEventClasse();
        }

        public void setRendezVousBindingSource(BindingSource rendezVousList, BindingSource typeList, BindingSource patientList, BindingSource medecinList)
        {
            
            dgView.DataSource = rendezVousList;
            cboxType.DataSource = typeList;
            cboxPatient.DataSource = patientList;
            cboxMedecin.DataSource = medecinList;

            dgView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;



        }



        //Design Pattern => Singleton

        

        public DateTime saisieDate 
        {
            get => cboDate.Value;
            set => throw new NotImplementedException(); 

        }
        
        public string type { 
            get =>cboxType.SelectedItem as string; 
            set => throw new NotImplementedException(); }
        string IViewsRdV.saisieHeure {
            get => saisieHeure.Text.Trim();
            set => saisieHeure.Text = value;
        }
        public DateTime libelleRechercheDate
        {
            get => cbDateC1.Value;
            set => throw new NotImplementedException();
        }
        public Patient Patient {
            get => cboxPatient.SelectedItem as Patient;
            set => throw new NotImplementedException();
        }
        public User User { 
            get => cboxMedecin.SelectedItem as User; 
            set => throw new NotImplementedException(); }

        public event EventHandler plannifierRdV;
        public event EventHandler annulerRdv;
        public event EventHandler ValiderRdv;
        public event EventHandler rechercherDate;
        public event EventHandler modifier;

        public void activeEventClasse()
        {
            //Mappe Ecouteur et Objet
             btnPlanif.Click += delegate { plannifierRdV.Invoke(this, EventArgs.Empty); };
             btnAnnuler.Click += delegate { annulerRdv.Invoke(this, EventArgs.Empty); };
             btnOk2.Click += delegate { rechercherDate.Invoke(this, EventArgs.Empty); };
             btnModifie.Click += delegate { modifier.Invoke(this, EventArgs.Empty); };

        }
        public void Cacherrv()
        {
            btnModifie.Visible = false;
        }
        public void CacherBtn()
        {
            btnPlanif.Visible = false;
        }


        private static FormRdV instance = null;


        public static FormRdV showForm(Form parent)
        {
            if (parent.ActiveMdiChild != null)
            {
                parent.ActiveMdiChild.Hide();
                instance = null;
            }
            if (instance == null || instance.IsDisposed)
            {
                instance = new FormRdV();
                instance.MdiParent = parent;
            }
            return instance;
        }


        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void cboxType_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void dgView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }


        private void label1_Click(object sender, EventArgs e)
        {

        }

        public void hide()
        {
            throw new NotImplementedException();
        }

        
    }
}
