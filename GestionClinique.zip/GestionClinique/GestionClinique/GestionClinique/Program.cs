﻿using Gestion_Clinique.views;
using GestionClinique.presenter;
using GestionClinique.services;
using GestionClinique.views;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GestionClinique
{
    internal static class Program
    {
        /// <summary>
        /// Point d'entrée principal de l'application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            IViewsConnexion views = new ConnexionView();
            IConnexionPresenter connexionPresenter = new ConnexionPresenter(views);
            Application.Run(views as ConnexionView);
        }
    }
}
