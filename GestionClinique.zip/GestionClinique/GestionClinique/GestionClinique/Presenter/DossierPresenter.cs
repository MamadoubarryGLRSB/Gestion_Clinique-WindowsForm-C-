﻿using GestionClinique.dto;
using GestionClinique.models;
using GestionClinique.services;
using GestionClinique.views;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GestionClinique.Presenter
{
    public class DossierPresenter:IDossierPresenter
    {
        private IDossierMedicalVews dossierMedicalVews;
        private Patient patient;
        private IConsultationService consultationService;
        private IPrestationService prestationService;

        public DossierPresenter(IDossierMedicalVews dossierMedicalVews, Patient patient)
        {
            this.DossierMedicalVews = dossierMedicalVews;
            this.Patient = patient;
            consultationService = Fabrique.GetConsultationService();
            prestationService=Fabrique.GetPrestationService();
            
            initialize();
            callBackEvent();
            this.DossierMedicalVews.Show();
        }
        IEnumerable<ConsultationDto> consultationList = new List<ConsultationDto>();
        IEnumerable<PrestationDto> prestationList = new List<PrestationDto>();
        IEnumerable<string> typList = new List<string>()
        {
            "Consultation","Prestation"
        };
        private BindingSource dossierList = new BindingSource();
        private BindingSource typeList = new BindingSource();

        public IDossierMedicalVews DossierMedicalVews { get => dossierMedicalVews; set => dossierMedicalVews = value; }
        public Patient Patient { get => patient; set => patient = value; }

        public void initialize()
        {
            this.DossierMedicalVews.nom = Patient.Nom;
            this.DossierMedicalVews.prenom = Patient.Prenom;
            this.DossierMedicalVews.code = Patient.Code;
            this.DossierMedicalVews.antecedent = Patient.Antecedent;
            this.DossierMedicalVews.sexe= Patient.Sexe;
            this.DossierMedicalVews.naissance = Patient.Date_Naissance;
            this.DossierMedicalVews.adresse = Patient.Adresse;
            this.DossierMedicalVews.telephone=Patient.Telephone;
            consultationList=consultationService.listerConsultationPatient(Patient);
            dossierList.DataSource= consultationList;
            typeList.DataSource= typList;
            DossierMedicalVews.setDossierBindingSource(dossierList, typeList);
            

        }
        public void callBackEvent()
        {
            this.DossierMedicalVews.ok += OkHandle;
        }

        private void OkHandle(object sender, EventArgs e)
        {
            string type = DossierMedicalVews.type;
            if (type.CompareTo("Consultation")==0)
            {
                consultationList = consultationService.listerConsultationPatient(Patient);
                dossierList.DataSource = consultationList;
            }
            else
            {
                prestationList = prestationService.listerPrestationPatient(Patient);
                dossierList.DataSource = prestationList;
            }

        }
    }
}
