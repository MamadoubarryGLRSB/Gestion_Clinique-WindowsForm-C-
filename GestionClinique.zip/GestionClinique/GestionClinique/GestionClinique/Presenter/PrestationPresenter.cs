﻿using GestionClinique.dto;
using GestionClinique.models;
using GestionClinique.services;
using GestionClinique.views;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GestionClinique.Presenter
{
    public class PrestationPresenter:IPrestationPresenter
    {
        private IViewsPrestation viewsPrestation;
        private IPrestationService prestationService;
        private IPatientService patientService;
        private User user;
        public PrestationPresenter(IViewsPrestation viewsPrestation)
        {
            this.viewsPrestation = viewsPrestation;
            prestationService=Fabrique.GetPrestationService();
            patientService=Fabrique.GetPatientService();
            callBackEvent();
            initialize();
            this.viewsPrestation.Show();
        }
        public PrestationPresenter(IViewsPrestation viewsPrestation,User user)
        {
            this.viewsPrestation = viewsPrestation;
            this.user = user;
            prestationService = Fabrique.GetPrestationService();
            patientService = Fabrique.GetPatientService();
            callBackEvent();
            initialize();
            if (user.Role == Role.secretaire)
            {
                this.viewsPrestation.btnCacheP();
            }
            this.viewsPrestation.Show();
        }
        //BindingSource pou charger les donnees
        private BindingSource bindingRendezVousPrestation = new BindingSource();
        private BindingSource bindingPatient = new BindingSource();
        public void callBackEvent()
        {
           
            this.viewsPrestation.rechercherPatient += rechercherPatientHandle;
            this.viewsPrestation.rechercherDate += rechercherDateHandle;
            this.viewsPrestation.voirDetail += detailHandle;


        }
        VoirDetailPrestation detailP = null;

        private void detailHandle(object sender, EventArgs e)
        {
            PrestationDto preste = bindingRendezVousPrestation.Current as PrestationDto;
            Prestation prestation=prestationService.finfById(preste.Id);
            if(detailP==null)
            {
                detailP = new VoirDetailPrestation(new DetailPrestatonForm(), prestation);

            }
            else
            {
                detailP.DetailPrestationV = new DetailPrestatonForm();
                detailP.Prestation = prestation;
                detailP.initialize();
                detailP.DetailPrestationV.Show();
            }
        }



        //List
        IEnumerable<PrestationDto> prestationList = new List<PrestationDto>();
        IEnumerable<PatientDto> patientList = new List<PatientDto>();
        public void initialize()
        {
            prestationList = prestationService.listerRdVPrestation();
            bindingRendezVousPrestation.DataSource = prestationList;
            patientList = patientService.listerPatient();
            bindingPatient.DataSource = patientList;


            this.viewsPrestation.setPrestationBindingSource(bindingRendezVousPrestation, bindingPatient);
        }

        private void rechercherDateHandle(object sender, EventArgs e)
        {
            DateTime date = viewsPrestation.libelleRechercheDate;
            prestationList = prestationService.listerPrestationBydate(date.ToShortDateString());
            bindingRendezVousPrestation.DataSource=prestationList;
        }
        

        private void rechercherPatientHandle(object sender, EventArgs e)
        {
            PatientDto patient = viewsPrestation.libelleRechechePatient;
            prestationList = prestationService.listerPrestationPatient(patient.toPatient());
            bindingRendezVousPrestation.DataSource = prestationList;
        }
        
       

        
    }
}
