﻿using GestionClinique.dto;
using GestionClinique.models;
using GestionClinique.presenter;
using GestionClinique.views;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionClinique.Presenter
{
    public class VoirDetailConsultationPresenter:IVoirDetailPresenter
    {
        private IDetailConsultationViews detailConsultationViews;
        private Consultation consultation;
        

        public VoirDetailConsultationPresenter(IDetailConsultationViews detailConsultationViews, Consultation consultation)
        {
            this.DetailConsultationViews = detailConsultationViews;
            this.consultation = consultation;
            initialize();
            this.DetailConsultationViews.Show();
        }

        public IDetailConsultationViews DetailConsultationViews { get => detailConsultationViews; set => detailConsultationViews = value; }
        public Consultation ConsultationDto { get => consultation; set => consultation = value; }

        public void initialize()
        {
            
            this.DetailConsultationViews.date = consultation.Date;
            this.DetailConsultationViews.prenompatient = consultation.Patient.Prenom;
            this.DetailConsultationViews.nompatient = consultation.Patient.Nom;
            this.detailConsultationViews.constantes = consultation.Constantes;
            
           

        }
    }
}
