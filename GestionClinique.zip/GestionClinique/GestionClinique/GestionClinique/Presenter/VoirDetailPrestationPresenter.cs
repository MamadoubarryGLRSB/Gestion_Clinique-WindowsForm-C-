﻿using GestionClinique.models;
using GestionClinique.views;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionClinique.Presenter
{
    public class VoirDetailPrestationPresenter:IVoirDetailPrestationPresenter
    {
        private IDetailPrestationViews detailPrestationViews;
        private Prestation prestation;

        public VoirDetailPrestationPresenter(IDetailPrestationViews detailPrestationViews, Prestation prestation)
        {
            this.DetailPrestationViews = detailPrestationViews;
            this.Prestation = prestation;
            initialize();
            this.DetailPrestationViews.Show();
        }

        public IDetailPrestationViews DetailPrestationViews { get => detailPrestationViews; set => detailPrestationViews = value; }
        public Prestation Prestation { get => prestation; set => prestation = value; }


        public void initialize()
        {

            this.detailPrestationViews.date = prestation.Date;
            this.detailPrestationViews.prenompatient = prestation.Patient.Prenom;
            this.detailPrestationViews.nompatient = prestation.Patient.Nom;
            this.detailPrestationViews.constantes = prestation.Constantes;



        }

    }
}
