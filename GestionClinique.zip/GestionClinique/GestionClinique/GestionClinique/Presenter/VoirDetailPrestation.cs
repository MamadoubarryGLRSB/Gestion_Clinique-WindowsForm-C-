﻿using GestionClinique.models;
using GestionClinique.views;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionClinique.Presenter
{
    public class VoirDetailPrestation:IVoirDetailPrestation
    {
        private IDetailPrestationV detailPrestationV;
        private Prestation prestation;

        public VoirDetailPrestation(IDetailPrestationV detailPrestationV, Prestation prestation)
        {
            this.DetailPrestationV = detailPrestationV;
            this.Prestation = prestation;
            initialize();
            this.DetailPrestationV.Show();
        }

        public IDetailPrestationV DetailPrestationV { get => detailPrestationV; set => detailPrestationV = value; }
        public Prestation Prestation { get => prestation; set => prestation = value; }

        public void initialize()
        {
            this.detailPrestationV.date = prestation.Date;
            this.detailPrestationV.prenompatient = prestation.Patient.Prenom;
            this.detailPrestationV.nompatient = prestation.Patient.Nom;
            this.detailPrestationV.constantes = prestation.Constantes;
        }
    }
}
