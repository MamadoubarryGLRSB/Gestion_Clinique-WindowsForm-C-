﻿using GestionClinique.models;
using GestionClinique.views;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionClinique.Presenter
{
    public class VoirDetailConsultPresenter:IVoirDetailPresenter
    {
        private IDetailConsultationViews detailConsultationViews;
        private Consultation consultation;

        public VoirDetailConsultPresenter(IDetailConsultationViews detailConsultationViews, Consultation consultation)
        {
            this.DetailConsultationViews = detailConsultationViews;
            this.Consultation = consultation;
            initialize();
            this.detailConsultationViews.Show();
        }

        public IDetailConsultationViews DetailConsultationViews { get => detailConsultationViews; set => detailConsultationViews = value; }
        public Consultation Consultation { get => consultation; set => consultation = value; }
        public void initialize()
        {
            this.detailConsultationViews.date = consultation.Date;
            this.detailConsultationViews.prenompatient = consultation.Patient.Prenom;
            this.detailConsultationViews.nompatient = consultation.Patient.Nom;
            this.detailConsultationViews.constantes = consultation.Constantes;
        }
    }
}
