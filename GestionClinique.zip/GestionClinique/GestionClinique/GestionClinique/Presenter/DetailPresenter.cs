﻿using GestionClinique.dto;
using GestionClinique.models;
using GestionClinique.presenter;
using GestionClinique.services;
using GestionClinique.views;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GestionClinique.Presenter
{
    public class DetailPresenter:IDetailPresenter
    {
        private IconsultV consultView;
        
        RendezVous rdv;
       
      
        private IConsultationService consultationService;
        private IPrestationService prestationService;
       
        public DetailPresenter(IconsultV consultView, RendezVous rdv)
        {
            this.consultView = consultView;
            this.rdv = rdv;
            consultationService = Fabrique.GetConsultationService();
            prestationService=Fabrique.GetPrestationService();
            initsialize();
            callBackEvent();
            this.consultView.Show();

        }
       

        public void initsialize()
        { 
            this.consultView.dateC= rdv.Date;
            this.consultView.prenomC = rdv.Patient.Prenom;
            this.consultView.nomC = rdv.Patient.Nom;
            this.consultView.dateP = rdv.Date;
            this.consultView.prenomP= rdv.Patient.Prenom;
            this.consultView.nomP= rdv.Patient.Nom;
            if (ConnexionPresenter.user.Role == Role.medecin)
            {
                this.consultView.prestation = false;
            } 
            if (ConnexionPresenter.user.Role == Role.rp)
            {
                this.consultView.consultation = false;
            }


        }
        public void callBackEvent()
        {
            this.consultView.enregistrer+= AjouterConsultationHandle;
            this.consultView.enregistrerPrestation+= AjouterPresestationHandle;
        }

        private void AjouterPresestationHandle(object sender, EventArgs e)
        {
            string constante = consultView.constantesP;
            if (string.IsNullOrEmpty(constante))
            {
                MessageBox.Show("Oups Veillez remplir le Champ");
            }
            else
            {
                string date = rdv.Date;
                Patient patient = rdv.Patient;
                Prestation prestation = new Prestation()
                {
                    Constantes = constante,
                    Date = date,
                    Patient = patient,
                };
                prestationService.ajouterPrestation(prestation);
                MessageBox.Show("Une Prestation a été Ajouté avec succès");
            }
        }

        private void AjouterConsultationHandle(object sender, EventArgs e)
        {
                string constante=consultView.constantesC;
                string date = rdv.Date;
                Patient patient = rdv.Patient;
                Consultation consultation = new Consultation()
                {
                    Constantes = constante,
                    Date = date,
                    Patient = patient,
                };
                consultationService.ajouterConsultation(consultation);
                MessageBox.Show("Une Consultation avec succès");
            
   
        }
    }
}
