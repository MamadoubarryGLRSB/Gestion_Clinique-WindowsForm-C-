﻿using Gestion_Clinique.views;
using GestionClinique.dto;
using GestionClinique.models;
using GestionClinique.services;
using GestionClinique.views;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace GestionClinique.Presenter
{
    public class ConsultationPresenter
    {
        //Dependance + couplage Faible
        private IViewsConsultation viewsConsultation;
        private IConsultationService consultationService ;
        private IPatientService patientService;
        private User user;

     
        public ConsultationPresenter(IViewsConsultation viewsConsultation)
        {

            this.viewsConsultation = viewsConsultation;
            consultationService=Fabrique.GetConsultationService();
            patientService = Fabrique.GetPatientService();
             initialize();
             callBackEvent();
            this.viewsConsultation.Show();
        }
        public ConsultationPresenter(IViewsConsultation viewsConsultation,User user)
        {

            this.viewsConsultation = viewsConsultation;
            this.user= user;
            consultationService = Fabrique.GetConsultationService();
            patientService = Fabrique.GetPatientService();
            initialize();
            callBackEvent();
            if (user.Role == Role.secretaire)
            {
                this.viewsConsultation.cacheBtnC() ;
            }
            this.viewsConsultation.Show();
        }
        //BindingSource pou charger les donnees
        private BindingSource bindingRendezVousConsultation = new BindingSource();
        private BindingSource bindingPatient = new BindingSource();

        //List
        IEnumerable<ConsultationDto> consultationList = new List<ConsultationDto>();
        //IEnumerable<DetailDto> detailList = new List<DetailDto>();
        IEnumerable<PatientDto> patientList = new List<PatientDto>();
        public void initialize()
        {
            consultationList = consultationService.listerRdVConsultation();
            bindingRendezVousConsultation.DataSource = consultationList;

            patientList = patientService.listerPatient();
            bindingPatient.DataSource = patientList;


            this.viewsConsultation.setConsultationBindingSource(bindingRendezVousConsultation, bindingPatient);
        }
        //Fonctions des rapples
        public void callBackEvent()
        {
            
            this.viewsConsultation.rechercherPatient += rechercherPatientHandle;
            this.viewsConsultation.rechercherDate += rechercherDateHandle;
            this.viewsConsultation.voirDetail += detailHandle;
            

        }

       

        VoirDetailConsultPresenter detailP=null;
        private void detailHandle(object sender, EventArgs e)
        {
            
            ConsultationDto consulte = bindingRendezVousConsultation.Current as ConsultationDto;
            Consultation consultation = consultationService.finfById(consulte.Id);
            if(detailP==null)
            {
                detailP = new VoirDetailConsultPresenter(new DetailConsultationForm(), consultation );

            }else
            {
                detailP.DetailConsultationViews = new DetailConsultationForm();
                detailP.Consultation = consultation;
                detailP.initialize();
                detailP.DetailConsultationViews.Show();
                

            }


        }
       




        private void rechercherDateHandle(object sender, EventArgs e)
        {
            DateTime date = viewsConsultation.libelleRechercheDate;
                consultationList = consultationService.listerConsultationBydate(date.ToShortDateString());
                bindingRendezVousConsultation.DataSource= consultationList;
            
        }

        private void rechercherPatientHandle(object sender, EventArgs e)
        {
            PatientDto patient = viewsConsultation.libelleRechechePatient;
             consultationList = consultationService.listerConsultationPatient(patient.toPatient());
             bindingRendezVousConsultation.DataSource = consultationList;
            
       }

       


       
    }
}
