﻿using Gestion_Clinique.views;
using GestionClinique.dto;
using GestionClinique.models;
using GestionClinique.Presenter;
using GestionClinique.services;
using GestionClinique.views;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ToolTip;

namespace GestionClinique.presenter
{
    public class RendezVousPresenter:IRendezVousPresenter
    {
        //Dependance + couplage Faible
        private IViewsRdV viewsRdV;
        private IRendezVousService rendezVousService;
        private IPatientService patientService;
        private IConsultationService consultationService;
        private IConnexionService connexionService;
        private User user;

        public RendezVousPresenter(IViewsRdV viewsRdV)
        {
            
            this.viewsRdV = viewsRdV;
            rendezVousService=Fabrique.GetRendezVousService();
            patientService = Fabrique.GetPatientService();
            connexionService = Fabrique.GetConnexionService();
            initialize();
            callBackEvent();
            this.viewsRdV.Show();
        }

        public RendezVousPresenter(User user, IViewsRdV viewsRdV)
        {
            this.user=user;
            this.viewsRdV = viewsRdV;
            rendezVousService = Fabrique.GetRendezVousService();
            patientService = Fabrique.GetPatientService();
            connexionService = Fabrique.GetConnexionService();
            initialize();
            callBackEvent();
            if(user.Role==Role.secretaire) {
                this.viewsRdV.Cacherrv();
            }
            if(user.Role==Role.medecin)
            {
                this.viewsRdV.CacherBtn();
            }
            this.viewsRdV.Show();

        }

        //BindingSource pou charger les donnees
        private BindingSource bindingRendezVous = new BindingSource();
        private BindingSource bindingType = new BindingSource();
        private BindingSource bindingPatient = new BindingSource();
        private BindingSource bindingUser = new BindingSource();

        //List
        IEnumerable<RendezVous> rendezvouslist = new List<RendezVous>();
        IEnumerable<string> typeList = new List<string>();
        IEnumerable<Patient> patientList = new List<Patient>();
        IEnumerable<User> usertList = new List<User>();



        public void initialize()
        {
            patientList = patientService.listerPatientP();
            bindingPatient.DataSource = patientList;
            rendezvouslist = rendezVousService.listerRdV();
            bindingRendezVous.DataSource = rendezvouslist;
            usertList=connexionService.listerMedecin();
            bindingUser.DataSource = usertList;
            
            typeList = new List<string>()
            {
               "Consultation","Prestation"
            };
            bindingType.DataSource=typeList;
           
            this.viewsRdV.setRendezVousBindingSource(bindingRendezVous , bindingType, bindingPatient,bindingUser);
        }

        //Definir les Fonctions de rappels
        public void callBackEvent()
        {
            this.viewsRdV.plannifierRdV += PlannifierHandle;
            this.viewsRdV.annulerRdv += annulerRdvHandle;
            this.viewsRdV.ValiderRdv += validerRdvHandle;
            this.viewsRdV.rechercherDate += rechercherDateHandle;
            this.viewsRdV.modifier += modifierHandle;

        }
        
        private void modifierHandle(object sender, EventArgs e)
        {
            
            RendezVous rdv = bindingRendezVous.Current as RendezVous;
 
              IDetailPresenter  detailspresenter = new DetailPresenter(new ConsultForm(),rdv);

        }
        

      private void rechercherDateHandle(object sender, EventArgs e)
        {
            DateTime date = viewsRdV.libelleRechercheDate;
            rendezvouslist = rendezVousService.listerConsultationBydate(date.ToShortDateString());
            bindingRendezVous.DataSource = rendezvouslist;

        }

        private void validerRdvHandle(object sender, EventArgs e)
        {
            RendezVous rendezvous = bindingRendezVous.Current as RendezVous;
            rendezvous.Etat = "Valider";
            rendezVousService.annulerRdv(rendezvous);
            rendezvouslist = rendezVousService.listerRdV();
            bindingRendezVous.DataSource = rendezvouslist;
        }

        private void annulerRdvHandle(object sender, EventArgs e)
        {
            RendezVous rendezvous = bindingRendezVous.Current as RendezVous;
            rendezvous.Etat = "Annuler";
            rendezVousService.annulerRdv(rendezvous);
            rendezvouslist = rendezVousService.listerRdV();
            bindingRendezVous.DataSource = rendezvouslist;

        }

        private void PlannifierHandle(object sender, EventArgs e)
        {
            
            string heure = viewsRdV.saisieHeure;
            if(string.IsNullOrEmpty(heure))
            {
                MessageBox.Show("Veillez Remplir tout les Champs");

            }else
            {
                string type = viewsRdV.type;
                Patient patient = viewsRdV.Patient;
                User user= viewsRdV.User;
                DateTime date = viewsRdV.saisieDate;
                RendezVous rendezvous = new RendezVous()
                {
                    Date = date.ToShortDateString(),
                    Heure = heure,
                    Type = type,
                    Patient = patient,
                    Medecin=user

                };
                rendezVousService.ajouterRdv(rendezvous);
                MessageBox.Show("Une rendez-vous avec succès");
                rendezvouslist = rendezVousService.listerRdV();
                bindingRendezVous.DataSource = rendezvouslist;
            }
           
        }
    }
}
