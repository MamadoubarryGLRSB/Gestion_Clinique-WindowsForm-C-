﻿using Gestion_Clinique.views;
using GestionClinique.models;
using GestionClinique.Presenter;
using GestionClinique.services;
using GestionClinique.views;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GestionClinique.presenter
{
    public class ConnexionPresenter:IConnexionPresenter
    {
        //Dependance + couplage Faible
        IViewsConnexion viewsConnexion;
        IConnexionService connexionService;

        //Injection de dependance
        public ConnexionPresenter(IViewsConnexion viewsConnexion)
        {
            this.viewsConnexion = viewsConnexion;
            connexionService=Fabrique.GetConnexionService();
            this.viewsConnexion.seConnecter += seConnecterHandle;

        }
        public static User user;

        private void seConnecterHandle(object sender, EventArgs e)
        {
            string login = this.viewsConnexion.Login;
            string password = this.viewsConnexion.Password;
             user = connexionService.seConnecter(login,password);
            if(user!=null)
            {
                //Création de la view Menu
                 IViewMenu menuView = new menuForm();
                 menuView.userConnect=user;
                //Récupération de l'utilisateur qui est connecté

              
                IMenuPresenter menuPresenter = new MenuPresenter(menuView);
                viewsConnexion.Hide();
                this.viewsConnexion.isLogin = true;


            }
            else
            {
                this.viewsConnexion.isLogin = false;
                this.viewsConnexion.Message = "Login ou Password Incorrect veillez reessayer";


            }
        }
    }
}
