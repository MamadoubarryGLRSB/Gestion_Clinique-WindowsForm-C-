﻿using Gestion_Clinique.views;
using GestionClinique.models;
using GestionClinique.presenter;
using GestionClinique.views;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace GestionClinique.Presenter
{
    public class MenuPresenter:IMenuPresenter
    {
        private IViewMenu viewMenu;

        public MenuPresenter(IViewMenu viewMenu)
        {
            this.viewMenu = viewMenu;
            this.viewMenu.userLabel = this.viewMenu.userConnect.NomComplet;
            this.viewMenu.Show();
            this.viewMenu.showRdV += showhandleRdV;
            this.viewMenu.showConsultation+=showhandleRdVConsultation;
            this.viewMenu.showPatient += showhandlePatient;
            this.viewMenu.showPrestation += showhandlPrestation;
            this.viewMenu.showDeconnection += shoHandleDeconnecte; ;

        }

        private void shoHandleDeconnecte(object sender, EventArgs e)
        {
            viewMenu.Close();

            IViewsConnexion connexion = new ConnexionView();
            IConnexionPresenter connexionPresenter = new ConnexionPresenter(connexion);
            connexion.Show();
        }

        private void showhandlPrestation(object sender, EventArgs e)
        {
            if(viewMenu.userConnect.Role==Role.rp || viewMenu.userConnect.Role == Role.secretaire)
            {
                IViewsPrestation viewsPrestation = FormPrestation.showForm(viewMenu as Form);
                new PrestationPresenter(viewsPrestation, viewMenu.userConnect);

            }else
            {
                viewMenu.prestation = false;
            }

            
        }

        private void showhandlePatient(object sender, EventArgs e)
        {
            if(viewMenu.userConnect.Role==Role.medecin || viewMenu.userConnect.Role == Role.secretaire)
            {
                IViewsPatient viewsPatient = PatientForm.showForm(viewMenu as Form);
                new PatientPresenter(viewMenu.userConnect, viewsPatient);

            }else
            {
                viewMenu.patient = false;
            }
         
            
        }

        private void showhandleRdVConsultation(object sender, EventArgs e)
        {
            if(viewMenu.userConnect.Role==Role.medecin || viewMenu.userConnect.Role == Role.secretaire)
            {
                IViewsConsultation viewsConsultation = FormConsultation.showForm(viewMenu as Form);
                new ConsultationPresenter(viewsConsultation, viewMenu.userConnect);
            }
            else
            {
                viewMenu.consultation = false;
            }
           
        }

        private void showhandleRdV(object sender, EventArgs e)
        {
            if (viewMenu.userConnect.Role == Role.secretaire || viewMenu.userConnect.Role == Role.medecin || viewMenu.userConnect.Role == Role.rp)
            {
                IViewsRdV rvView = FormRdV.showForm(viewMenu as Form);
                new RendezVousPresenter(viewMenu.userConnect,rvView);


            }
            else
            {
                viewMenu.rdv = false;
            }
            
        }
    }
}
