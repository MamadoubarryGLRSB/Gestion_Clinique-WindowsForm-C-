﻿using Gestion_Clinique.views;
using GestionClinique.dto;
using GestionClinique.models;
using GestionClinique.services;
using GestionClinique.views;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ToolTip;

namespace GestionClinique.Presenter
{
    public class PatientPresenter:IPatientPresenter
    {
        //Dependance + couplage Faible
        private IViewsPatient viewsPatient;
        private IPatientService patientService;
        private User user;
        public PatientPresenter(IViewsPatient viewsPatient)
        {

            this.viewsPatient = viewsPatient;
            patientService = Fabrique.GetPatientService();
            this.initialize();
            this.viewsPatient.Show();
            this.callBackEvent();
        }

        public PatientPresenter(User user, IViewsPatient viewsPatient)
        {
            this.user = user;
            this.viewsPatient = viewsPatient;
            patientService = Fabrique.GetPatientService();
            this.initialize();
            this.viewsPatient.Show();
            if (user.Role == Role.medecin)
            {
                this.viewsPatient.CacherBtn();
            }
            
            this.callBackEvent();
        }

        //BindingSource pou charger les donnees
        private BindingSource bindingPatient = new BindingSource();

        //List
        IEnumerable<PatientDto> classeListPatient = new List<PatientDto>();

        public void initialize()
        {
            classeListPatient = patientService.listerPatient();
            bindingPatient.DataSource = classeListPatient;


            this.viewsPatient.setClasseBindingSource(bindingPatient );
        }
        //Definir les Fonctions de rappels
        public void callBackEvent()
        {
            this.viewsPatient.ajouterPatient += AjouterPatientHandle;
            this.viewsPatient.dossier += DossierHandle;
           
           

        }
        DossierPresenter dossier = null;


        private void DossierHandle(object sender, EventArgs e)
        {
            PatientDto patiente = bindingPatient.Current as PatientDto;
            Patient patient = patientService.finfById(patiente.Id);
            if(dossier==null)
            {
                dossier = new DossierPresenter(new DossierMedicalForm(), patient);
            }
            else
            {
                dossier.DossierMedicalVews = new DossierMedicalForm();
                dossier.Patient= patient;
                dossier.initialize();
                dossier.DossierMedicalVews.Show();
            }
            
        }

     

        private void AjouterPatientHandle(object sender, EventArgs e)
        {
            string nom = viewsPatient.saisieNom;
            
            string prenom = viewsPatient.saisiePrenom;
            string antecedent=viewsPatient.saisieAntecedent;
            string sexe=viewsPatient.saisieSexe;
            string naiss = viewsPatient.saisieDateNaissance;
            string adresse=viewsPatient.saisieAdresse;
            string telephone=viewsPatient.saisieTelephone;
            if(string.IsNullOrEmpty(nom) || string.IsNullOrEmpty(prenom)||string.IsNullOrEmpty(antecedent)||string.IsNullOrEmpty(sexe)||string.IsNullOrEmpty(naiss)||string.IsNullOrEmpty(adresse)|| string.IsNullOrEmpty(telephone))
            {
                MessageBox.Show("Veillez Remplir tout les Champs");
            }else
            {
                Patient patient = new Patient()
                {
                    Nom = nom,
                    Prenom = prenom,
                    Antecedent = antecedent,
                    Sexe = sexe,
                    Date_Naissance = naiss,
                    Adresse = adresse,
                    Telephone = telephone

                };
                patientService.ajouterPatient(patient);
                MessageBox.Show("Un Patient a été Ajouter avec succès");
                classeListPatient = patientService.listerPatient();
                bindingPatient.DataSource = classeListPatient;
            }
            

            

        }
    }
}
