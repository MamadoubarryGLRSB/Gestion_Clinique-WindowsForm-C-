﻿using GestionClinique.models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionClinique.dto
{
    public class PatientDto
    {
        private int id;
        private string nom;
        private string prenom;
        private string code;
        public int Id { get => id; set => id = value; }
        public string Nom { get => nom; set => nom = value; }
        public string Prenom { get => prenom; set => prenom = value; }
        
        public override string ToString()
        {
            return nom + " " + prenom;
        }
        public Patient toPatient()
        {
            return new Patient()
            {
                Id = id,
                Nom = nom,
                Prenom = prenom,
                Code = code,


            };
        }
    }
}
