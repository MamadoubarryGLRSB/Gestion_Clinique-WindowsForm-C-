﻿using GestionClinique.models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionClinique.dto
{
    public class ConsultationDto
    {
        private string date;
        private string time;
       
        private Patient patient;
        private int id;
        private string nomMedecin;
      

        public int Id { get => id; set => id = value; }
        public string Date { get => date; set => date = value; }
        
      
        public Patient Patient { get => patient; set => patient = value; }
        
    }
}
