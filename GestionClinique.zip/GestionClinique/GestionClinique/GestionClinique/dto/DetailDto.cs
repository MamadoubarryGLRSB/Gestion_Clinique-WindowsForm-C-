﻿using GestionClinique.models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionClinique.dto
{
    public class DetailDto
    {
        private string date;
        private string time;
        private int id;

        private Patient patient;
        private string constantes;
        

        public string Date { get => date; set => date = value; }
        public string Time { get => time; set => time = value; }
       
        public Patient Patient { get => patient; set => patient = value; }
        public int Id { get => id; set => id = value; }
        public string Constantes { get => constantes; set => constantes = value; }

        /**
        public Consultation toConsultation()
        {
            return new Consultation()
            {
                Id = Id,
                Date = date,
                Patient = patient,
            };
        }
        */

    }
}
